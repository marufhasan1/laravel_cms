<?php

namespace App\Providers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;

use App\Helpers\Meta;

class AppServiceProvider extends ServiceProvider {
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot() {
        // set the default string length
        Schema::defaultStringLength(191);

        // theme settings
        View::share('width', Meta::settings('width'));
        View::share('theme', Meta::settings('theme'));
        View::share('powered_by', Meta::settings('powered_by'));
        View::share('developed_by', Meta::settings('developed_by'));
        View::share('developer_mode', Meta::settings('developer_mode'));

        // View::share('width', 'container');
        // View::share('theme', 'light');
        // View::share('powered_by', 'coderill');
        // View::share('developed_by', 'jayanta biswas');
        // View::share('developer_mode', 0);
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
