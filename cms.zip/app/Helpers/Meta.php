<?php
/**
 * Created by Jayanta Biswas
 * Date: 2/5/2018
 * Time: 12:14 PM
 */

namespace App\Helpers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class Meta {

    /**
     * @param $table
     * @param $where
     * @return mixed
     */
    private static function action($table, $where) {
        return DB::table($table)->where($where)->get();
    }

    /**
     * @param $table
     * @param $condition
     * @return mixed
     */
    public static function get($table, $condition) {
        $where = (!is_array($condition)) ? [['meta_key', '=', $condition]] : $condition;
        return self::action($table, $where);
    }

    /**
     * @param $key
     * @return mixed
     */
    public static function profile($key) {
        $where = [
            ['auth_id', '=', Auth::user()->id],
            ['meta_key', '=', $key]
        ];

        $records = self::action('profiles', $where);

        return $records[0]->meta_value;
    }

    /**
     * @param $key
     * @return mixed
     */
    public static function settings($key) {
        $where = [
            ['meta_key', '=', $key]
        ];

        $records = self::get('settings', $where);

        return $records[0]->meta_value;
    }

}
