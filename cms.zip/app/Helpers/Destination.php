<?php
/**
 * Created by PhpStorm.
 * User: Jayanta
 * Date: 5/14/2018
 * Time: 6:19 PM
 */

namespace App\Helpers;


class Destination
{

    private static function setURL($origins, $destinations) {
        return "https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=" . $origins[0] . "," . $origins[1] . "&destinations=" . $destinations[0] . "," . $destinations[1] . "&key=AIzaSyADduHOvQ5P50nX-Oq6plLJ5IoJJMswpLk&sensor=true";
    }

    public static function getLength($origins, $destinations) {
        $data = [];
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => setURL($origins, $destinations),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                // Set Here Your Requesred Headers
                'Content-Type: application/json',
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            $data = $err;
        } else {
            $data = json_decode($response, true);
        }

        return $data;
    }

}