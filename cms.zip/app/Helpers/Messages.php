<?php

namespace App\Helpers;

class Messages {

    /**
     * bootstrap alert message
     *
     * @param $state :success/info/warning/danger
     * @param $message
     * @return string
     */
    private static function set($state, $message) {
        $content  = '<div class="alert alert-' . $state . ' alert-dismissible" role="alert">';
        $content .= '<button type="button" class="close" data-dismiss="alert" aria-label="Close">';
        $content .= '<span aria-hidden="true">&times;</span>';
        $content .= '</button>';
        $content .= '<strong>' . ucwords($state) . '</strong>';
        $content .= '<p>' . $message . '</p>';
        $content .= '</div>';

        return $content;
    }

    /**
     * @param $state
     * @param $message
     * @return string
     */
    public static function get($state, $message) {
        return self::set($state, $message);
    }

}