<?php
/**
 * Created by Jayanta Biswas
 * Date: 2/5/2018
 * Time: 12:14 PM
 */

namespace App\Helpers;

use Illuminate\Support\Facades\DB;
/**
 *
 */
class Unique {

    /**
     * @var
     */
    private static $key;

    /**
     * @param $table
     * @param $column
     * @param array $where
     * @param $length
     * @return string
     */
    private static function process($table, $column, $where = [], $length) {
        $unique = false;
        $archive = [];

        // if the where condition is exists get the latest row from db
        $last = (count($where) > 0)
            ? (array) DB::table($table)->where([$where])->orderBy($column, 'DESC')->first()
            : (array) DB::table($table)->orderBy($column, 'DESC')->first();

        // check the row exists or not
        if($last != null) {
            do {
                // Generate random number
                $random = $last[$column] + 1;

                // Check if it's already testing
                // If so, don't query the database again
                if(in_array($random, $archive)) { continue; }

                // Check if it is unique in the database
                $count = (count($where) > 0)
                    ? DB::table($table)->where([[$column, '=', $random], $where])->count()
                    : DB::table($table)->where($column, '=', $random)->count();

                // Store the random character in the tested array
                // To keep track which ones are already tested
                $archive[] = $random;

                // String appears to be unique
                if($count == 0) {
                    $unique = true; // Set unique to true to break the loop
                }

                // If unique is still false at this point
                // it will just repeat all the steps until
                // it has generated a random string of characters
            } while (!$unique);
        } else {
            $random = 1;
        }

        return str_pad($random, $length, "0", STR_PAD_LEFT);
    }

    /**
     * @param null $emit
     * @param int $length
     * @return string
     */
    public static function generate($emit = null, $length = 4) {
        if($emit != null) {
            $where = [];

            if(array_key_exists(2, $emit)) {
                if(is_array($emit[2])) {
                    $where = $emit[2];
                }
            }

            self::$key = self::process($emit[0], $emit[1], $where, $length);
        } else {
            self::$key = strtoupper(md5(microtime().rand()));
        }

        return self::$key;
    }


}

?>
