<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 4/3/2018
 * Time: 6:13 PM
 */

namespace App\Helpers;

use Illuminate\Support\Facades\DB;

class Maruf{

    public static function get_search_data($filter){
    	$final_datas = array();
    	
    	if($filter!=null && $filter!=""){
	    	$datas = self::get_data($filter);
			foreach ($datas as $key => $value) {
				$value = (array)$value;
				$result = self::splice_address($value);
				//print_r($result);
				$final = self::set_search_data($result,$filter); 
				if($final!=null){
					$final_datas[] = $final;
				}
			}
    	}

    	// return $datas;
		return json_encode($final_datas);
    }

    private static function get_data($filter){
		$sql="SELECT * FROM addresses WHERE CONCAT(IFNULL(`street`, ''), '',IFNULL(`city`, ''), '', IFNULL(`state`, ''), '', IFNULL(`zipcode`, ''), '', IFNULL(`country`, ''), '', IFNULL(`restaurant`, ''), '', IFNULL(`tag_name`, '')) LIKE '%$filter%' LIMIT 5";
        return DB::select($sql);
    }

	private static function splice_address($array){
		$output = array();
		extract($array);
		$output["address"] = $street.",".$city.",".$state.",".$zipcode.",".$country;
		$output["restaurant"] = $restaurant;
		$output["tag_name"] = $tag_name;
		$output["data"] = $array;
		return $output;
	}

	private static function set_search_data($arr,$str){
		//$arr as Array
		//$str as String for search
		//$deny as array to deny the field for low priority
		$data = $arr["data"];
		unset($arr["data"]);

		$matches = array();
		$not_matches = array();
		foreach($arr as $k=>$v) {
			if(preg_match("/$str/i", $v)) {
				$matches[$k] = $v;
			}else{
				$not_matches[$k] = $v;
			}
		}

		if(count($matches)>0){
			$result_array = array(
				"string" => self::set_pattern($matches,$not_matches),
				"data" => $data
			);
		//Returning An array
		return $result_array;
		}
		return null;
	}

	private static function set_pattern($matches,$not_matches){
		$result_string = "";
		$res_arr = array_merge($matches,$not_matches);
		extract($res_arr);
		$pattern = [
			"address" => $address,
			"restaurant" => $restaurant.",".$address,
			"tag_name" => $restaurant.",".$address
		];

		$k = array_flip($matches);
		$k = reset($k);
		$result_string = $pattern[$k];
		return $result_string;
	}
}