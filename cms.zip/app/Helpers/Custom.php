<?php
namespace App\Helpers;
use App\Models\Message;

class Custom{

    public static function isJson($str) {
        $json = json_decode($str, true);
        return (is_array($json)) ? ((count($json) > 0) ? true : false) : false;
    }

    public static function array_remove_empty($array) {
        return array_filter($array, function($value) {
            return !empty($value) || $value === 0;
        });
    }

    public static function UnreadMSG() {
    	$msg = new Message;
    	$data = $msg->where("status","unread")->get()->count();
    	return $data;
    }
    

}