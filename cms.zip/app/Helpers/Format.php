<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 3/1/2018
 * Time: 7:04 PM
 */

namespace App\Helpers;

class Format {

    /**
     * @param $input
     * @return int
     */
    public static function integer($input) {
        return (int) $input;
    }

    /**
     * @param $input
     * @return float
     */
    public static function decimal($input) {
        return (float) $input;
    }



}