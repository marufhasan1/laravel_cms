<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Appearance extends Model
{
	public $timestamps = false;
    protected $table = "appearance";
    protected $fillable = ["companies_id","key","value"];
}
