<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Companies extends Model
{
    protected $table = "companies";
    protected $fillable = ['users_id','company_name','type','contact_number','site_url','route','city','state','zipcode','country','address','created_at','updated_at'];

    public function user(){
        return $this->belongsTo("App\User","users_id");
    }

    public function company_uploades(){
        return $this->hasMany("App\Models\CompanyUploade","companies_id");
    }

    public function company_meta(){
    	return $this->hasMany("App\Models\CompanyMeta","companies_id");
    }

    public function menus(){
    	return $this->hasMany("App\Models\Menus","companies_id");
    }

    public function appearance(){
    	return $this->hasMany("App\Models\Appearance","companies_id");
    }
}

