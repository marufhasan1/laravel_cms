<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanyUploade extends Model
{
	public $timestamps = false;
    protected $table = "company_uploades";
    protected $fillable = ['companies_id','users_id','upload_key','upload_path'];
}