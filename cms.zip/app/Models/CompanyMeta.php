<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanyMeta extends Model
{
	public $timestamps = false;
    protected $table = "company_meta";
    protected $fillable = ['companies_id','users_id','meta_key','meta_value'];
}