<?php
namespace App\Http\Middleware;

use Closure;
use App\Models\Companies;

class CheckTheme
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $account_id = $request->route("account");
        $info = Companies::with("user")->where("site_url",$account_id)->first();
        //dd($info);
        if(!$info){
            return redirect("theme_404");
        }elseif($info->status!="active"){
            return redirect("theme_inactive");
        }


        return $next($request);
    }
}
