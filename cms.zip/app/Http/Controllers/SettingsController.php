<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Helpers\Messages as MSG;

class SettingsController extends Controller {

    public $data = [
        'width' => 'container',
        'menu' => 'settings',
        'active' => 'settings',
        'nav' => 'backend.settings.nav', // in view,
        'help' => [
            'instruction' => 'admin.settings.instruction' // route name
        ],
    ];

    public function __construct() {
        $this->middleware("auth:admin");
    }

    public function index() {
        $this->data['help']['video'] = '';

        return view('backend.settings.theme')->with($this->data);
    }

    /**
     * @return $this
     */
    public function instruction() {
        $this->data['active'] = $this->data['menu'] . '-instruction';
        $this->data['help']['video'] = '';

        return view('backend.extra.instruction')->with($this->data);
    }

}
