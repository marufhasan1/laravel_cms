<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Companies;
use App\Models\CompanyUploade;
use App\User;

class ThemeController extends Controller
{

	public $data = [
		"theme" => 'default'
	];

	public function __construct(Request $request){
		$this->middleware('ckTheme');
	}



    public function index(Request $request, $account_id){
		$this->data["info"] = $this->getinfo($request);

		//Retriving gallery data
		$this->data["gallery_image"] = $info = Companies::with(["company_uploades"=>function($q){
			$q->where("upload_key","gallery_image");
		}])->where("site_url",$request->account)->first();

		//dd($this->data["gallery_image"]);

        return view('theme.'.$this->data["theme"].'.home')->with($this->data);
    }


	private function getinfo($request){
		$info = Companies::with(["user","company_uploades","company_meta","menus","appearance"])->where("site_url",$request->account)->first();

		//Setting Company Meta information start here
		foreach ($info->company_meta as $key => $value) {
			$info->company_meta[$value->meta_key] = $value->meta_value;
			unset($info->company_meta[$key]);
		}
		//Setting Company Meta information end here

		//Setting Company Uploads information start here
		foreach ($info->company_uploades as $key => $value) {
			$info->company_uploades[$value->upload_key] = $value->upload_path;
			unset($info->company_uploades[$key]);
		}
		//Setting Company Uploads information end here

		if($info!=null){
			foreach ($info->appearance as $key => $value) {
				if(array_search("theme", (array)$value)){
					$this->data["theme"] = $value["value"];
					break;
				}
			}
		}
		return $info;
	}
}
