<?php
namespace App\Http\Controllers;

use App\Helpers\Meta;
use Log;

class AdminController extends Controller {

    public $data = [
        'width' => 'container',
        'menu' => 'dashboard',
        'nav' => 'backend.dashboard.nav', // in view
        'help' => [
            'instruction' => 'admin.dashboard.instruction' // route name
        ],
    ];

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $this->data['active'] = 'none';
        $this->data['help']['print'] = true;

        return view('backend.dashboard', compact(['dob']))->with($this->data);
    }

    public function instruction() {
        $this->data['active'] = $this->data['menu'] . '-instruction';

        return view('backend.extra.instruction')->with($this->data);
    }

}
