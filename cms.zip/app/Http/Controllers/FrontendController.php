<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Mail;
use App\Models\Companies;

class FrontendController extends Controller
{
    public $data = [];
    
    public function index(){
        return view('frontend.home')->with($this->data);
    }
}