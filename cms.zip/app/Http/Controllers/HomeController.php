<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Companies;
class HomeController extends Controller
{
    public $data = [];

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(){
        $this->middleware('auth');
    }

	public function dashboard() {
        //$data = Companies::with(["company_uploades","company_meta","menus","appearance"])->find(1);
        //dd($data);


        return view('user_panel.dashboard')->with($this->data);
    }

    public function createNewCompany(Request $request) {
        if($request->isMethod("post")){
            $this->validate($request, [
                'company_name'    => 'required|max:100',
                'type'            => 'required|max:100',
                'contact_number'  => 'required|max:100',
                'site_url'        => 'required|unique:companies',
                'route'           => 'max:50',
                'city'            => 'max:50',
                'state'           => 'max:50',
                'zipcode'         => 'max:50',
                'country'         => 'required|max:50'
            ]);

            $address = $request->route.", ".$request->city.", ".$request->state." ".$request->zipcode.", ".$request->country;
            $company = new Companies;
            $company->users_id       = Auth::user()->id;
            $company->company_name   = $request->company_name;
            $company->type           = $request->type;
            $company->contact_number = $request->contact_number;
            $company->site_url       = $request->site_url;
            $company->route          = $request->route;
            $company->city           = $request->city;
            $company->state          = $request->state;
            $company->zipcode        = $request->zipcode;
            $company->country        = $request->country;
            $company->address        = $address;
            if($company->save()){
                $request->session()->flash("msg","Company Successfully Created!");
            }

        }

        return view('user_panel.create-company')->with($this->data);
    }


    public function showAllCompany(){
        $where = [
            ["users_id","=",Auth::user()->id]
        ];
        $this->data["restaurants"] = Companies::where($where)->get();
        
        return view('user_panel.show-company')->with($this->data);
    }



    public function login(){
        
    }
}


