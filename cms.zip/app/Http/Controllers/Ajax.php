<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class Ajax extends Controller {

    /**
     * @param Request $request
     * @return array
     */
    public function retrieve(Request $request) {
        $result = [];

        if($request->has('where')) {
            $result = DB::table($request->table)->where($request->where)->get();
        } else {
            $result = DB::table($request->table)->get();
        }

        return $result;
    }

    public function exist(Request $request) {
        if($request->has('where')) {
            echo DB::table($request->table)->where($request->where)->exists();
        }else{
            echo "Condition Required";
        }
    }

    /**
     * @param Request $request
     * @return array
     */
    public function join(Request $request) {
        $result = [];

        if($request->has('where')) {
            $result = DB::table($request->table)->join($request->join, $request->joincond[0], $request->joincond[1], $request->joincond[2])->where($request->where)->get();
        } else {
            $result = DB::table($request->table)->join($request->join, $request->joincond[0], $request->joincond[1], $request->joincond[2])->get();
        }

        return $result;
    }

}
