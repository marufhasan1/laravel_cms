<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Companies;
use App\Models\CompanyUPloade;
use Illuminate\Support\Facades\Storage;
use App\Helpers\Messages as MSG;
use Session;
class CompanyController extends Controller
{
     /**
     * default settings
     * @var array
     */
    public $data = [
        'width' 	=> 'container',
        'menu' 		=> 'company',
        'active' 	=> 'none',
        'nav' 		=> 'backend.company.nav', // in view
        'help' 		=> [],
    ];

    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct() {
        $this->middleware('auth:admin');
    }

    public function add(Request $request){
        $this->data['active'] = $this->data['menu'] . '-add';
        $this->data['help']['video'] = '';
        $this->data['help']['print'] = true;

        if($request->isMethod("post")){

            $this->validate($request, [
                'site_url' => 'required|unique:companies|max:15',
            ]);

            $company = new Companies;
            $company->users_id        = "1";
            $company->company_name    = $request->company_name;
            $company->type            = $request->type;
            $company->contact_number  = $request->contact_number;
            $company->site_url        = $request->site_url;
            $company->street_number   = $request->street_number;
            $company->route           = $request->route;
            $company->city            = $request->city;
            $company->state           = $request->state;
            $company->zipcode         = $request->zipcode;
            $company->country         = $request->country;
            $company->address         = $request->street_number." ".$request->route.", ".$request->city.", ".$request->state.", ".$request->zipcode.", ".$request->country;
            if($company->save()){
                $request->session()->flash('success', MSG::get('success', 'Company Successfully Created!'));
            }
        }


        return view('backend.company.add')->with($this->data);
    }

    public function all(Request $request){
        $this->data['active'] = $this->data['menu'] . '-all';
        $this->data['help']['video'] = '';
        $this->data['help']['print'] = true;
        Session::forget('selected_company_id');

        $this->data["info"] = Companies::all();

        return view('backend.company.all')->with($this->data);
    }

    public function DeleteCompany($id){
        $images = CompanyUploade::where("companies_id",$id)->get();
        foreach($images as $key=>$img){
            Storage::delete($img->upload_path);
        }

        Companies::find($id)->delete();
        return redirect()->back();
    }

    public function SetEditSession(Request $request,$id){
        Session::put("selected_company_id",$id);
        return redirect("admin/company/update");
    }

}
