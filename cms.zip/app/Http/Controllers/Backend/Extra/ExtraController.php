<?php

namespace App\Http\Controllers\Backend\Extra;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ExtraController extends Controller {

    public $data = [
        'width' => 'container',
        'menu' => 'extra',
        'nav' => 'backend.extra.nav',
    ];

    public function __construct() {
        $this->middleware("auth:admin");
    }

    public function blank() {
        $this->data['active']= 'blank';

        return view('backend.extra.blank')->with($this->data);
    }

}
