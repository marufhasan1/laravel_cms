<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

use App\Admin;
use App\Role;

use App\Helpers\Messages as MSG;

class AdminRegistrationController extends Controller {

    /**
     * default settings
     * @var array
     */
    public $data = [
        'width' => 'container',
        'menu' => 'registration',
        'active' => 'none',
        'nav' => 'backend.registration.nav', // in view
        'help' => [
            'instruction' => 'admin.registration.instruction' // route name
        ],
    ];

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth:admin');
    }

    /**
     * Show the application admin registration form.
     *
     */
    public function showRegistrationForm() {
        $this->data['help']['video']    = '';

        // get roles
        $roles = Role::all();

        return view('backend.registration', compact(['roles']))->with($this->data);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function registration(Request $request) {
        // validation
        $this->validate($request, [
            'fullname' => 'required|max:100',
            'email'    => 'required|email|unique:admins,email',
            'username' => 'required|unique:admins,username|min:8',
            'password' => 'required|confirmed|min:8',
            'privilege' => 'required',
        ], [], [
            'fullname' => 'Full name',
        ]);

        // insert into admins table
        $admin = new Admin;

        $admin->name = $request->fullname;
        $admin->email = $request->email;
        $admin->username = $request->username;
        $admin->password = Hash::make($request->password);
        $admin->role = $request->privilege;

        $admin->save();

        // flash message
        $request->session()->flash('success', MSG::get('success', 'Account successfully created!'));

        // redirect
        return redirect()->back();
    }

    /**
     * @return $this
    **/


    public function records() {
        $this->data['help']['video'] = 'url';

        // get all records from admins table
        $records = DB::table('admins')->paginate(15);

        return view('backend.registration.records', compact('records'))->with($this->data);
    }

    /**
     * @param $id
     * @return $this
     */
    public function details($id) {
        $this->data['help']['video'] = 'url';

        // get all records from admins table
        $records = Admin::findorfail($id);

        return view('backend.registration.details', compact('records'))->with($this->data);
    }

    /**
     * @param Request $request
     * @param $id
     * @return $this
     */
    public function showChangeForm(Request $request, $id) {
        $this->data['help']['video'] = 'url';

        // get all roles
        $roles = Role::all();

        // get the record from admins table
        $record = Admin::find($id);

        return view('backend.registration.change', compact(['id', 'roles', 'record']))->with($this->data);
    }

    /**
     * @param Request $request
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function change(Request $request, $id) {
        // validation
        $this->validate($request, [
            'fullname' => 'required|max:100',
            'password' => 'required|confirmed|min:8',
            'privilege' => 'required',
        ], [], [
            'fullname' => 'Full name',
        ]);

        // update the record into admins table
        $admin = Admin::find($id);

        $admin->name = $request->fullname;
        $admin->password = Hash::make($request->password);
        $admin->role = $request->privilege;

        $admin->save();

        // flash message
        $request->session()->flash('confirmation', MSG::get('success', 'Account successfully updated!'));

        // redirect
        return redirect()->back();
    }

    /**
     * @param Request $request
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function remove(Request $request, $id) {
        // delete from admins table
        $record = Admin::find($id);

        // flash message
        if($record->delete()) {
            $request->session()->flash('confirmation', MSG::get('danger', 'Account successfully deleted!'));
        }

        return redirect()->back();
    }

    /**
     * @return $this
     */
    public function instruction() {
        $this->data['active'] = $this->data['menu'] . '-instruction';

        return view('backend.extra.instruction')->with($this->data);
    }

}
