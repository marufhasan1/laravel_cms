<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Session;
use App\Models\Companies;
use App\Models\CompanyUploade;
use App\Models\CompanyMeta;
use App\Models\Appearance;
use App\Helpers\Messages as MSG;
use Auth;
class UpdateCompanyController extends Controller
{
     /**
     * default settings
     * @var array
     */
    public $data = [
        'width' 	=> 'container',
        'menu' 		=> 'company',
        'active' 	=> 'none',
        'nav' 		=> 'backend.company.update_nav', // in view
        'help' 		=> [],
    ];

    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct() {
        $this->middleware(['auth:admin','validCompany']);
    	$this->data["company_id"] = Session::get("selected_company_id");
    }

    public function index(Request $request){
        $this->data['active'] = $this->data['menu'] . '-all';
        $this->data['help']['print'] = true;

        $cid = $this->data["company_id"];

        if($request->isMethod("post")){

            if($request->hasFile('banner')){ //Updating Banner Image
                Storage::delete($request->old_banner);
                $this->validate($request, [
                    'image' => 'image|mimes:jpeg,png,jpg,gif|max:3072',
                ]);
                $path = $request->file('banner')->store('upload');

                $where = [
                    "users_id" => Auth::user()->id,
                    "companies_id" => $cid,
                    "upload_key" => "banner"
                ];
                $company_upload = CompanyUploade::firstOrCreate($where);
                $company_upload->upload_path = $path;
                $company_upload->save();
            }

            //Updating Subtitle
                $where = [
                    "users_id" => Auth::user()->id,
                    "companies_id" => $cid,
                    "meta_key" => "subtitle"
                ];

                $company_meta = CompanyMeta::firstOrCreate($where);
                $company_meta->meta_value = $request->subtitle;
                $company_meta->save();
            //Updating Company Name
                $company_meta = Companies::findOrFail($cid);
                $company_meta->company_name = $request->company_name;
                $company_meta->save();

                $request->session()->flash('success', MSG::get('success', 'Data Successfully Updated!'));
        }


        //Retriving Data Here
        $this->data["info"] = Companies::where("id",$cid)->with([
            "company_uploades" => function($q){
                $q->where("upload_key","banner");
            },
            "company_meta" => function($q){
                $q->where("meta_key","subtitle");
            }])->first();


        return view('backend.company.update_header')->with($this->data);
    }

    public function about_company(Request $request){
        $this->data['active'] = $this->data['menu'] . '-all';
        $this->data['help']['print'] = true;
        
        $cid = $this->data["company_id"];

        $where = [
            "users_id"     => Auth::user()->id,
            "companies_id" => $cid,
            "meta_key"     => "about_company"
        ];

        
        if($request->isMethod("post")){
        //Updating Subtitle
            $company_meta = CompanyMeta::firstOrCreate($where);
            $company_meta->meta_value = $request->about_company;
            $company_meta->save();

            

            if($request->hasFile('about_image')){ //Updating Banner Image
                Storage::delete($request->old_image);
                $this->validate($request, [
                    'image' => 'image|mimes:jpeg,png,jpg,gif|max:3072',
                ]);
                $path = $request->file('about_image')->store('upload');

                $where1 = [
                    "users_id" => Auth::user()->id,
                    "companies_id" => $cid,
                    "upload_key" => "about_image"
                ];
                $company_upload = CompanyUploade::firstOrCreate($where1);
                $company_upload->upload_path = $path;
                $company_upload->save();
            }

            $request->session()->flash('success', MSG::get('success', 'Data Successfully Updated!'));

        }




        $this->data["info"] = CompanyMeta::where($where)->first();
        
        unset($where["meta_key"]);
        $where["upload_key"] = "about_image";

        $this->data["about_image"] = CompanyUploade::where($where)->first();

        return view('backend.company.update_aboutCompany')->with($this->data);
    }

    public function gallery_image(Request $request){
        $this->data['active'] = $this->data['menu'] . '-all';
        $this->data['help']['print'] = true;

        $cid = $this->data["company_id"];

        
        if($request->isMethod("post")){

            if($request->hasFile('image')){ //Updating Banner Image
                $this->validate($request, [
                    'image' => 'image|mimes:jpeg,png,jpg,gif|max:3072',
                ]);
                $path = $request->file('image')->store('upload');

                $company_upload = new CompanyUploade;
                $company_upload->users_id     = Auth::user()->id;
                $company_upload->companies_id = $cid;
                $company_upload->upload_key   = "gallery_image";
                $company_upload->upload_path  = $path;
                $company_upload->save();
            }

            $request->session()->flash('success', MSG::get('success', 'Data Successfully Updated!'));

        }

        $where = [
            "users_id" => Auth::user()->id,
            "companies_id" => $cid,
            "upload_key" => "gallery_image"
        ];

        $this->data["images"] = CompanyUploade::where($where)->get();

        return view('backend.company.update_GalleryImage')->with($this->data);
    }

    public function DeleteGalleryImage(Request $request,$id){
        $image = CompanyUploade::find($id);
        if(Storage::delete($image->upload_path)){
            CompanyUploade::find($id)->delete();
        }
        $request->session()->flash('success', MSG::get('danger', 'Image Successfully Deleted!'));
        return redirect()->back();
    }

    public function business_hours(Request $request){
        $this->data['active'] = $this->data['menu'] . '-all';
        $this->data['help']['print'] = true;

        if($request->isMethod("post")){
            
        }

        return view('backend.company.update_BusinessHours')->with($this->data);
    }

    public function others(Request $request){
        $this->data['active'] = $this->data['menu'] . '-all';
        $this->data['help']['print'] = true;
        $cid = $this->data["company_id"];



        if($request->isMethod("post")){//Updating Data
            if($request->map!=null){
                $map = new \DOMDocument();
                $map->loadHTML($request->map);
                $map_src = $map->getElementsByTagName( 'iframe' )[0]->getAttribute ( 'src' );

                $where = [
                    "users_id" => Auth::user()->id,
                    "companies_id" => $cid,
                    "meta_key" => "map_source"
                ];

                $company_meta = CompanyMeta::firstOrCreate($where);
                $company_meta->meta_value = $map_src;
                $company_meta->save();
            }

            //Updating Address and contact No
            $company_meta = Companies::findOrFail($cid);
            $company_meta->contact_number   = $request->contact_number;
            $company_meta->street_number    = $request->street_number;
            $company_meta->route            = $request->route;
            $company_meta->city             = $request->city;
            $company_meta->state            = $request->state;
            $company_meta->zipcode          = $request->zipcode;
            $company_meta->country          = $request->country;
            $company_meta->save();
        }



        //Retriving Data
        $info = Companies::with(["company_meta"])->where("id",$cid)->first();
        //Setting Company Meta information start here
        foreach ($info->company_meta as $key => $value) {
            $info->company_meta[$value->meta_key] = $value->meta_value;
            unset($info->company_meta[$key]);
        }
        //Setting Company Meta information end here
        $this->data["info"] = $info;

        return view('backend.company.update_Others')->with($this->data);
    }

    public function ChoiceTheme(Request $request){
        $this->data['active'] = $this->data['menu'] . '-all';
        $this->data['help']['print'] = true;
        $cid = $this->data["company_id"];
 
        $allData = [];
        $allTheme = Storage::disk("theme")->directories();
        foreach ($allTheme as $key => $theme) {
            $info = json_decode(Storage::disk("theme")->get($theme."/info.json"));
            $info->thumb = "resources/views/theme/".$theme."/thumb.png";
            $info->id = $theme;
            $allData[] = $info;
        }
        $this->data["allTheme"] = $allData;

        //Fetch Current Data
        $where = ["companies_id" => $cid, "key" => "theme"];
        $this->data["current"] = Appearance::where($where)->first();
        
        return view('backend.company.choiceTheme')->with($this->data);
    }

    public function SetTheme(Request $request, $theme){
        $cid = $this->data["company_id"];
        $where = ["companies_id" => $cid, "key" => "theme"];

        $appearance = Appearance::firstOrCreate($where);
        $appearance->value = $theme;
        $appearance->save();

        $request->session()->flash('success', MSG::get('success', 'Theme Successfully Changed'));
        return redirect()->back();
    }

}