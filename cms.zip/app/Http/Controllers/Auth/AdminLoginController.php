<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Auth;

class AdminLoginController extends Controller {
    use AuthenticatesUsers;

    // Amount of bad attempts user can make
    protected $maxLoginAttempts = 5;

    // Time for which user is going to be blocked in seconds
    protected $lockoutTime = 10;

    /**
     * AdminLoginController constructor.
     */
    public function __construct() {
        $this->middleware('guest:admin', ['except' => ['logout']]);
    }

    /**
     * @return $this
     */
    public function showLoginForm() {
        $data = [
            'title' => 'Signin'
        ];

        return view('backend.auth.login')->with($data);
    }

    /*
    public function login(Request $request) {
        // validate the form data
        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required|min:6'
        ]);

        // attempt to log the user in
        if(Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request->password], $request->remember)) {
            // if successful, then redirect to intended location
            return redirect()->intended(route('admin.dashboard'));
        }

        // if not, then redirect back to the login form with form data
        $errors = ["email" => trans('auth.failed')];

        if ($request->expectsJson()) {
            return response()->json($errors, 422);
        }
        return redirect()->back()->withInput($request->only('email', 'remember'))->withErrors($errors);
    }
    */

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function login(Request $request) {
        // validate the form data
        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required|min:6'
        ]);

        // If the class is using the ThrottlesLogins trait, we can automatically throttle
        // the login attempts for this application. We'll key this by the username and
        // the IP address of the client making these requests into this application.
        if ($this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);

            return $this->sendLockoutResponse($request);
        }

        // attempt to log the user in
        if ($this->attemptLogin($request)) {
            // set the log
            $this->log('login', [
                'ip' => $request->ip(),
                'user_agent' => $request->header('User-Agent'),
                'email' => $request->email
            ]);

            $request->session()->regenerate();

            $this->clearLoginAttempts($request);

            // if successful, then redirect to intended location
            return redirect()->intended(route('admin.dashboard'));
        }

        // If the login attempt was unsuccessful we will increment the number of attempts
        // to login and redirect the user back to the login form. Of course, when this
        // user surpasses their maximum number of attempts they will get locked out.
        $this->incrementLoginAttempts($request);

        return $this->sendFailedLoginResponse($request);
    }

    /**
     * @param Request $request
     * @return mixed
     */
    protected function attemptLogin(Request $request) {
        // set the log
        $this->log('login-attempt', [
            'ip' => $request->ip(),
            'user_agent' => $request->header('User-Agent'),
            'email' => $request->email
        ]);

        return Auth::guard('admin')->attempt($this->credentials($request), $request->has('remember'));
    }

    /**
     * @param Request $request
     * @return bool
     */
    protected function hasTooManyLoginAttempts(Request $request) {
        return $this->limiter()->tooManyAttempts($this->throttleKey($request), $this->maxLoginAttempts, $this->lockoutTime);
    }

    /**
     * @param $key
     * @param $data
     */
    protected function log($key, $data) {
        \Log::info($key, ['user' => $data]);
    }

    /**
     * Log the user out of the application.
     *
     */
    public function logout(Request $request) {
        // set the log
        $this->log('logout', [
            'ip' => $request->ip(),
            'user_agent' => $request->header('User-Agent'),
            'email' => Auth::guard('admin')->user()->email
        ]);

        Auth::guard('admin')->logout();
        // $request->session()->invalidate();

        // if successful, then redirect to intended location
        // return redirect('/');
        return redirect()->intended(route('admin.login'));
    }

}
