var app = angular.module('Mainapp', ['angularUtils.directives.dirPagination']).run(function ($rootScope) {

    $rootScope.ajax = window.location.origin + '/admin/ajax/';

    console.log('running');
    console.log($rootScope.ajax);

});

// display absolute value, using Math library
app.filter('abs', function() {
    return function (input) {
        return Math.abs(input);
    };
});

// capitalize 1st letter of the input
app.filter('ucfirst', function() {
    return function (input) {
        return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
    };
});

// remove underscore and ucwords
app.filter("textBeautify", function(){
    return function (str) {
        var txt = '';

        if(typeof str != 'undefined') {
            var str = str.replace(/_/gi, " ").toLowerCase();

            txt = str.replace(/\b[a-z]/g, function(letter) {
                return letter.toUpperCase();
            });
        }

        return txt;
    }
});
