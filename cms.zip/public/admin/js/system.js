$(document).ready(function() {
    var developermode = false;

    var wrapper = $(".wrapper");
    var wrapperbg = $(".wrapper-background");

    // aside toggle, hide and show programm start
    function asideToggle() {
        if(wrapper.hasClass('aside-close')) {
            wrapper.removeClass("aside-close");
        } else {
            wrapper.addClass("aside-close");
        }
    }

    function asideHide() {
        wrapper.addClass("aside-close");
    }

    function asideShow() {
        wrapper.removeClass("aside-close");
    }

    function layer() {
        var display = false;

        // get the window width
        var winwidth = $(window).outerWidth(true);
        console.log(winwidth);

        if(winwidth <= 992) {
            if(wrapperbg.hasClass('none')) {
                wrapperbg.removeClass('none');
                display = false;
            } else {
                wrapperbg.addClass('none');
                display = true;
            }
        }

        return display;
    }

    // click on toggle button (toggle)
    $("#aside-toggle").on("click", function(event) {
        asideToggle();
        layer();

        event.preventDefault();
    });

    // click on the wrapper-background (close)
    $(".wrapper-background").on("click", function() {
        asideHide();
        layer();
    });

    // click on the aside-close (close)
    $('i#aside-close').on("click", function() {
        asideHide();
        layer();
    });

    // on resize event aside toggle (toggle, optional)
    $(window).on("resize", function() {
        if(developermode) {
            asideToggle();
            layer();
        }
    });
    // aside toggle, hide and show programm end









    // dropdown toggle programm start
    $(".dropdown > a").on("click", function(event) {

        var parent = $(this).closest("li.dropdown");

        if(parent.hasClass("active")) {
            parent.removeClass("active");
        } else {
            parent.addClass("active");
        }

        // console.log(parent);
        event.preventDefault();
    });
    // dropdown toggle programm end










    // print media
    $('#print').click(function() {
        window.print();
    });










    /**
     * add the nicescroll plugin
     * @param  {Element} html document
     */
    $("html, .aside-container, .body-container").niceScroll({
        cursorcolor: 'rgba(152, 166, 173, 0.5)',
        cursorwidth: '6px',
        cursorborderradius: '0px'
    });










    /**
     *
     */
    var menu = $('.column.aside').data('menu'),
        submenu = $('.column.aside').data('submenu'),
        page = $('nav.submenu').data('page');

    var li = '.aside-container li#' + menu;

    $(li).addClass('active');
    $(li + ' ul li#' + submenu).addClass('active');
    $('nav.submenu li[data-label=' + page + '] a').addClass('active');


    // video tutorial programm
    var src;
    $('#tutorial').on('click', function(e) {
        $("div.tutorial iframe").attr('src', src);

        $('div.tutorial').fadeIn(function() {
            $("div.tutorial iframe").fadeIn();
        });

        e.preventDefault();
    });

    $('div.tutorial > div').on('click', function() {
        $("div.tutorial iframe").fadeOut(function() {
            $('div.tutorial').fadeOut();

            src = $("div.tutorial iframe").attr('src');
            $("div.tutorial iframe").attr('src','');
        });
    });

});

// preloader
$(window).on('load', function() {
    $('#status').fadeOut();
    $('#preloader').delay(350).fadeOut('slow');
    console.log(1);
});
