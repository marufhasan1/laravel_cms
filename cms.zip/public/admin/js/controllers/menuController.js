app.controller('MenuCtrl', ['$rootScope', '$scope', '$http', function ($rootScope, $scope, $http) {

    $scope.recipes = [
        {
            item: '',
            price: 0.00,
            details: ''
        }
    ];

    $scope.addRecipe = function() {
        var item = {
            item: '',
            price: 0.00,
            details: ''
        };

        $scope.recipes.push(item);
        // console.log('add');
    };

    $scope.removeRecipe = function($index) {
        $scope.recipes.splice($index, 1);
    };



}]);
