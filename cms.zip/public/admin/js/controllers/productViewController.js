app.controller('ProductViewCtrl', ['$rootScope', '$scope', '$http', function ($rootScope, $scope, $http) {
    $scope.desckey = [];
    $scope.price_type = null;
    $scope.single_price = null;
    $scope.prices = [];
    
    $scope.$watch('[description,price]', function (meta) {
        var description = (meta[0]!=null)? JSON.parse(meta[0]) : [];
        var price = meta[1];
        //$scope.desckey = description;
        description.forEach(function(el,i){
            $scope.desckey.push({key:i,value:el});
        });
        
        //console.log(typeof(price));
        if ((typeof (price) == "object")){
            $scope.price_type = "multiple";

            Object.keys(price).forEach(function (p) {
                $scope.prices.push({ storage: p, price: price[p] });
            });

        }else{
            $scope.price_type = "single";
            $scope.single_price = price;
        }

    });

    $scope.addPrice = function () {
        $scope.prices.push({ storage: "", price: "" });
    };

    $scope.removePrice = function ($index) {
        $scope.prices.splice($index, 1);
    };

    $scope.addDescription = function () {
        $scope.desckey.push({ key: $scope.desckey.length + 1, value: "" });
    };

    $scope.removeDescription = function ($index) {
        $scope.desckey.splice($index, 1);
    };
}]);
