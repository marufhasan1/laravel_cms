app.controller('ProductCtrl', ['$rootScope', '$scope', '$http', function ($rootScope, $scope, $http) {
    $scope.prices = [1];
    $scope.desckey = [1];
    $scope.addPrice = function () {
        $scope.prices.push($scope.prices.length+1);
    };
    
    $scope.removePrice = function ($index) {
        $scope.prices.splice($index, 1);
    };

    $scope.addDescription = function () {
        $scope.desckey.push($scope.desckey.length+1);
    };

    $scope.removeDescription = function ($index) {
        $scope.desckey.splice($index, 1);
    };
}]);
