-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2019 at 07:37 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `branch` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `branch`, `name`, `email`, `username`, `auth_key`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, '', 'US-IT Solution', 'info@usitsolution.net', 'usitsolution', '87Z0AMTFyAiI', '$2y$10$35AhdR49DB0.DjlWJXVQdODMAgZt.uyLJ8JTZkqslUfq6T6xKany2', 'administrator', 'UK1srbimyptvELpzZQD7UPPLovtkM7SpYr0qS6XEM2I40dJfxb5RVujMJMMv', '2018-03-07 06:50:52', '2018-03-07 06:50:52'),
(2, '', 'Twister Wireless', 'info@twisterokc.com', 'twisterokc', NULL, '$2y$10$2kglWTCjsWDWwizNMSMK0ub.85aYfOqXH8bZBBEORxcaw1yFhkPGq', 'administrator', 'XCWS7Vyu2JAiWZHHXmEnebTZOmFSBfGGqGf4j5ZDiv0LmYqtrwgJOTFXzTEw', '2018-10-27 04:19:10', '2018-10-27 04:22:59');

-- --------------------------------------------------------

--
-- Table structure for table `appearance`
--

CREATE TABLE `appearance` (
  `id` int(11) NOT NULL,
  `companies_id` int(11) NOT NULL,
  `key` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'e.g. theme,theme_color',
  `value` longtext COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='This table will contain the information like company website theme, theme color etc.';

--
-- Dumping data for table `appearance`
--

INSERT INTO `appearance` (`id`, `companies_id`, `key`, `value`) VALUES
(1, 12, 'theme', 'theme1'),
(2, 11, 'theme', 'theme1'),
(3, 14, 'theme', 'theme1'),
(4, 13, 'theme', 'default');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `company_name` varchar(191) CHARACTER SET utf8 DEFAULT NULL,
  `type` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `contact_number` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `site_url` varchar(191) CHARACTER SET utf8 DEFAULT NULL,
  `street_number` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `route` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `state` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `zipcode` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `address` longtext CHARACTER SET utf8 DEFAULT NULL,
  `status` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `users_id`, `company_name`, `type`, `contact_number`, `site_url`, `street_number`, `route`, `city`, `state`, `zipcode`, `country`, `address`, `status`, `created_at`, `updated_at`) VALUES
(11, 1, 'Classen Foods', 'smoke_shope', '405-525-0565', 'classenfoods', '3121', 'N Classen Blvd', 'Oklahoma City', 'OK', '73118', 'USA', '3121 N Classen Blvd, Oklahoma City, OK, 73118, USA', 'active', '2019-02-12 09:58:55', '2019-02-12 09:58:55'),
(12, 1, 'US IT Solution', 'smoke_shope', '01735189237', 'usit', '3121', 'N Classen Blvd', 'Oklahoma City', 'OK', '73118', 'United States', 'N Classen Blvd N Classen Blvd, Oklahoma City, OK, 73118, United States', 'active', '2019-09-30 05:26:59', '2019-02-13 04:30:55'),
(13, 1, 'Your Company Name', 'smoke_shope', '01700000000', 'mycompany', '3121', 'N Classen Blvd', 'Oklahoma City', 'OK', '73118', 'USA', '3121 N Classen Blvd, Oklahoma City, OK, 73118, USA', 'active', '2019-02-13 04:07:12', '2019-02-13 04:07:12'),
(14, 1, 'Test', 'smoke_shope', '654654654654654', 'test', '654654', '654654', '654654', '654654', '654654', '654654', '654654 654654, 654654, 654654, 654654, 654654', 'active', '2019-02-20 08:01:50', '2019-02-20 08:01:50');

-- --------------------------------------------------------

--
-- Table structure for table `company_meta`
--

CREATE TABLE `company_meta` (
  `id` int(11) NOT NULL,
  `companies_id` int(11) NOT NULL,
  `users_id` int(11) DEFAULT NULL,
  `meta_key` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `company_meta`
--

INSERT INTO `company_meta` (`id`, `companies_id`, `users_id`, `meta_key`, `meta_value`) VALUES
(17, 11, 1, 'subtitle', '3121 N Classen Blvd, Oklahoma City, OK 73118, USA'),
(18, 11, 1, 'about_company', '<p>Lorem Ipsum&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>'),
(20, 12, 1, 'subtitle', '34, Muktijoddha Sarani (Choto Bazar)  Mymensingh-2200,'),
(21, 12, 1, 'about_company', 'Our full-service creative and digital marketing agency, specializing in custom web design and development for businesses that feel their branding strategy is &quot;coasting&quot; at best. Our full-service creative and digital marketing agency, specializing in custom web design and development for businesses that feel their branding strategy is &quot;coasting&quot; at best. Our full-service creative and digital marketing agency, specializing in custom web design and development for businesses that feel their branding strategy is &quot;coasting&quot; at best.'),
(22, 12, 1, 'map_source', 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d4308.6216407888105!2d90.40128173242095!3d24.757606207443448!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x37564f1d2c66b637%3A0xf8ebedd1537b1e9b!2sNotun+Bazar!5e0!3m2!1sen!2sbd!4v1549968064223'),
(23, 11, 1, 'map_source', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d574.1923802173312!2d-97.53484212288983!3d35.50124644600333!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87b210a8b48abe95%3A0x2979d0bdb3aac6d6!2sClassen+Foods!5e0!3m2!1sen!2sbd!4v1551264604795');

-- --------------------------------------------------------

--
-- Table structure for table `company_uploades`
--

CREATE TABLE `company_uploades` (
  `id` int(11) NOT NULL,
  `users_id` int(11) DEFAULT NULL,
  `companies_id` int(11) NOT NULL,
  `upload_key` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `upload_path` longtext CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='This table will contain all uploaded file path or information';

--
-- Dumping data for table `company_uploades`
--

INSERT INTO `company_uploades` (`id`, `users_id`, `companies_id`, `upload_key`, `upload_path`) VALUES
(25, 1, 11, 'banner', 'upload/29hnSMpa93Bq9ckkUJi18JX64p8VAl6jNkOBenD6.jpeg'),
(27, 1, 11, 'about_image', 'upload/EG2cg8YI2Tzby9g0xrnPW0yBkaIPUzuhCFeqMzH0.jpeg'),
(35, 1, 12, 'banner', 'upload/V3K8qcBLwidV5yUPQ5f1iHI3QQiSS9N03AjWqLB2.jpeg'),
(36, 1, 12, 'about_image', 'upload/WpTUo0lrFg3eTNMpZ1OvC9toazfvwc9cG5igdYK8.jpeg'),
(37, 1, 12, 'gallery_image', 'upload/tq2SKlUYMxui9KAkQINLR8IMu4SP2AlVcIZZCqaG.jpeg'),
(38, 1, 12, 'gallery_image', 'upload/GXpTdADzFWVMlKKikxh4uYcJs98KKk2FzqZSifcb.jpeg'),
(39, 1, 12, 'gallery_image', 'upload/RI0a9IniOCxygihX8fbRIe8utF7vzeE0hTAIc35q.jpeg'),
(40, 1, 12, 'gallery_image', 'upload/fkrBhWmUGaVDP3zcgFGTEToTOG5Iris6XS8aZfuO.jpeg'),
(41, 1, 12, 'gallery_image', 'upload/9lX3D64jOy2NMVCUJBXk4DdOUrIzHXoITL3qoOtw.jpeg'),
(42, 1, 12, 'gallery_image', 'upload/cnlJ6lJCHe5vLPEXVnU0VFtWN0cm4bOjCYefZ3av.jpeg'),
(48, 1, 11, 'gallery_image', 'upload/vOdVVA4CfUbB1shDzuCwKbE4rYFsA2sbg4mswkvt.jpeg'),
(49, 1, 11, 'gallery_image', 'upload/oeMt7MUlokSX4anD8hAPX8qvY8RRZQFk8z6KUNpo.jpeg'),
(50, 1, 11, 'gallery_image', 'upload/IYLU1x1txSFciw1Jvnn69CvSOgopdc3D4lbbSzVF.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `companies_id` int(11) NOT NULL,
  `menu_name` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `status` varchar(45) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int(11) NOT NULL,
  `menus_id` int(11) NOT NULL,
  `title` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `href` longtext CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu_subitems`
--

CREATE TABLE `menu_subitems` (
  `id` int(11) NOT NULL,
  `menu_items_id` int(11) NOT NULL,
  `title` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `href` longtext CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(33, '2014_10_12_000000_create_users_table', 1),
(34, '2014_10_12_100000_create_password_resets_table', 1),
(35, '2017_09_03_103056_create_admins_table', 1),
(36, '2018_01_24_194430_create_roles_table', 1),
(37, '2018_02_02_040047_create_profiles_table', 1),
(38, '2018_02_02_040621_create_settings_table', 1),
(39, '2018_03_20_162449_create_sessions_table', 1),
(40, '2018_04_03_175258_create_addresses_table', 1),
(41, '2018_05_26_145337_create_favourites_table', 1),
(42, '2018_07_11_101405_create_orders_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `auth_id` int(10) UNSIGNED NOT NULL,
  `meta_key` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `meta_value` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `label` varchar(191) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `auth_id`, `meta_key`, `meta_value`, `label`) VALUES
(1, 2, 'street', 'Street Address', ''),
(2, 2, 'city', 'City Name', ''),
(3, 2, 'state', 'State Name', ''),
(4, 2, 'zip_code', '12345', ''),
(5, 2, 'country', 'Bangladesh', '');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `slug`, `permissions`) VALUES
(1, 'ADMINISTRATOR', 'administrator', '[\"write\",\"read\",\"edit\",\"delete\",\"publish\",\"download\",\"share\",\"approve\"]'),
(2, 'SUPERADMIN', 'superadmin', '[\"write\",\"read\",\"edit\",\"delete\",\"publish\",\"download\",\"share\",\"approve\"]'),
(3, 'EDITOR', 'editor', '[\"write\",\"read\",\"edit\",\"delete\",\"publish\",\"download\",\"share\"]'),
(4, 'AUTHOR', 'author', '[\"write\",\"read\",\"edit\",\"delete\",\"publish\",\"download\",\"share\"]'),
(5, 'CONTRIBUTOR', 'contributor', '[\"write\",\"read\",\"edit\",\"delete\",\"publish\",\"download\"]'),
(6, 'SUBSCRIBER', 'subscriber', '[\"write\",\"read\",\"edit\",\"delete\",\"publish\",\"download\",\"share\"]');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `meta_key` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `meta_value` text COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `meta_key`, `meta_value`) VALUES
(1, 'width', 'container'),
(2, 'theme', 'light'),
(3, 'powered_by', 'usitsolution'),
(4, 'developed_by', 'jayanta biswas'),
(5, 'developer_mode', '1'),
(6, 'load_time', '10');

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE `themes` (
  `id` int(11) NOT NULL,
  `theme_name` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `theme_slug` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `short_description` longtext CHARACTER SET utf8 DEFAULT NULL,
  `resource_path` longtext CHARACTER SET utf8 DEFAULT NULL COMMENT 'The Resource Folder url of the theme resources like html and style sheet'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `theme_colormodels`
--

CREATE TABLE `theme_colormodels` (
  `id` int(11) NOT NULL,
  `theme_slug` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `color_name` varchar(45) CHARACTER SET utf8 DEFAULT NULL COMMENT 'e.g. Pink,Blue,Orange',
  `style_description` longtext CHARACTER SET utf8 DEFAULT NULL COMMENT 'JSON [{section1:color code},{section2:colorcode}]'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `theme_meta`
--

CREATE TABLE `theme_meta` (
  `id` int(11) NOT NULL,
  `themes_id` int(11) NOT NULL,
  `meta_key` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `phone_number` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `role` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'free',
  `verifyToken` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone_number`, `password`, `approved`, `role`, `verifyToken`, `remember_token`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Maruf', 'Hasan', 'emarufhasan@gmail.com', '01735189237', '$2y$10$8fvctd2llVLdtcqhgsz4Q.KV/.vtshkMFg7YNt//DBnvuhk0Y8jDi', 1, 'free', NULL, '49andlVSyFTI30pYRtLWslzHIFRbWnAGmQbrjAmyo9hPVbWsCEAU7ggE9QuX', 'active', '2018-11-12 12:15:33', '2018-11-12 12:16:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`),
  ADD UNIQUE KEY `admins_username_unique` (`username`),
  ADD UNIQUE KEY `admins_auth_key_unique` (`auth_key`);

--
-- Indexes for table `appearance`
--
ALTER TABLE `appearance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_preference_companies1_idx` (`companies_id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_companies_users_idx` (`users_id`);

--
-- Indexes for table `company_meta`
--
ALTER TABLE `company_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_company_texts_companies1_idx` (`companies_id`);

--
-- Indexes for table `company_uploades`
--
ALTER TABLE `company_uploades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_company_uploades_companies1_idx` (`companies_id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_menus_companies1_idx` (`companies_id`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_menu_items_menus1_idx` (`menus_id`);

--
-- Indexes for table `menu_subitems`
--
ALTER TABLE `menu_subitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_menu_subitems_menu_items1_idx` (`menu_items_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_slug_unique` (`slug`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `theme_slug_UNIQUE` (`theme_slug`);

--
-- Indexes for table `theme_colormodels`
--
ALTER TABLE `theme_colormodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_theme_colormodels_themes2_idx` (`theme_slug`);

--
-- Indexes for table `theme_meta`
--
ALTER TABLE `theme_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_theme_meta_themes1_idx` (`themes_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `appearance`
--
ALTER TABLE `appearance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `company_meta`
--
ALTER TABLE `company_meta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `company_uploades`
--
ALTER TABLE `company_uploades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menu_subitems`
--
ALTER TABLE `menu_subitems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `themes`
--
ALTER TABLE `themes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `theme_colormodels`
--
ALTER TABLE `theme_colormodels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `theme_meta`
--
ALTER TABLE `theme_meta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appearance`
--
ALTER TABLE `appearance`
  ADD CONSTRAINT `fk_appearance_companies1` FOREIGN KEY (`companies_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `fk_companies_users` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `company_meta`
--
ALTER TABLE `company_meta`
  ADD CONSTRAINT `fk_company_texts_companies1` FOREIGN KEY (`companies_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `company_uploades`
--
ALTER TABLE `company_uploades`
  ADD CONSTRAINT `fk_company_uploades_companies1` FOREIGN KEY (`companies_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `menus`
--
ALTER TABLE `menus`
  ADD CONSTRAINT `fk_menus_companies1` FOREIGN KEY (`companies_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD CONSTRAINT `fk_menu_items_menus1` FOREIGN KEY (`menus_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `menu_subitems`
--
ALTER TABLE `menu_subitems`
  ADD CONSTRAINT `fk_menu_subitems_menu_items1` FOREIGN KEY (`menu_items_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `theme_colormodels`
--
ALTER TABLE `theme_colormodels`
  ADD CONSTRAINT `fk_theme_colormodels_themes1` FOREIGN KEY (`theme_slug`) REFERENCES `themes` (`theme_slug`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `theme_meta`
--
ALTER TABLE `theme_meta`
  ADD CONSTRAINT `fk_theme_meta_themes1` FOREIGN KEY (`themes_id`) REFERENCES `themes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
