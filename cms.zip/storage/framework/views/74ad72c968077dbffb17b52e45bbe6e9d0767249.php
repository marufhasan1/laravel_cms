<?php $__env->startSection('content'); ?>
    <section class="account">
        <div class="container">
            <div class="row">
                <div class="account-form">
                    <h4 class="section-title">Sign In</h4>

                    <?php if($errors->has('email')): ?>
                        <p class="msg-alert"><em>Wrong Username or, Password</em></p>
                    <?php endif; ?>

                    <form class="pt-3" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <input type="email" class="form-input" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email Address" required autofocus>
                        </div>

                        <div class="<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <input type="password" class="form-input" name="password" placeholder="Your Password" required>
                        </div>

                        <div>
                            <label>
                                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                Remember Me
                            </label>
                        </div>

                        <div>
                            <button type="submit" class="btn btnSubmit">Sign In Now</button>
                        </div>
                    </form>

                    <p class="text-link">
                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">Forgot Your Password?</a>
                    </p>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', ['page' => 'index', 'search' => false], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>