<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e($info->company_name); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset("public/theme/".$theme."/vendor/bootstrap/css/bootstrap.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("public/theme/".$theme."/vendor/fontawesome/css/all.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("public/theme/".$theme."/style.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("public/theme/".$theme."/css/responsive.css")); ?>">
</head>
<body>
    <!-- navigation section -->
    <div id="menu" class="bg-info">
        <nav class="navbar navbar-expand-md navbar-dark bg-info fixed-top">
                    <div class="container">
            <a href="#" class="navbar-brand">US IT SOLUTION</a>
            <button class="navbar-toggler" data-toggle="collapse" data-target="#my-menu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="my-menu">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a href="#menu" class="nav-link">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="#about" class="nav-link">About</a>
                    </li>
                    <li class="nav-item">
                        <a href="#service" class="nav-link">Service</a>
                    </li>
                    <li class="nav-item">
                        <a href="#contact" class="nav-link">Contact</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
    <!-- end navigation section -->
    <?php echo $__env->yieldContent('content'); ?>
<!-- footer section -->
<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="footer-nav text-center">
                    <ul class="nav justify-content-center">
                        <li class="nav-item">
                            <a class="nav-link text-light" href="#home">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="#about">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="#service">Service</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-light" href="#contact">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <ul class="social text-center mb-0">
                    <li><a href=""> <i class="fab fa-facebook"></i> </a></li>
                    <li><a href=""> <i class="fab fa-twitter"></i> </a></li>
                    <li><a href=""> <i class="fab fa-instagram"></i> </a></li>
                    <li><a href=""> <i class="fab fa-linkedin"></i> </a></li>
                    <li><a href=""> <i class="fab fa-youtube"></i> </a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-center py-0">
                <p class="lead mt-0">Powered By: <a href="https://usitsolution.net/" class="text-light">US IT Solution LLC</a></p>
            </div>
        </div>
    </div>
</footer>
<!-- end footer section -->





    <!-- all optional script -->
    <script src="<?php echo e(asset("public/theme/".$theme."/js/jQuery.js")); ?>"></script>
    <script src="<?php echo e(asset("public/theme/".$theme."/vendor/bootstrap/js/bootstrap.min.js")); ?>"></script>
    <script src="<?php echo e(asset("public/theme/".$theme."/vendor/fontawesome/js/all.min.js")); ?>"></script>
    <script src="<?php echo e(asset("public/theme/".$theme."/js/script.js")); ?>"></script>
</body>
</html>