<!-- main navigation start -->
<nav class="main-nav" role="<?php echo e($role); ?>">

    <!-- left navigation start -->
    <div class="pull-left">
        <ul>
            <li><a href="#" id="aside-toggle"><i class="material-icons mi-23">menu</i></a></li>
            <li><a href="#"><i class="material-icons mi-23">person</i></a></li>

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <span>New</span>
                    <span class="caret"></span>
                </a>

                <ul class="dropdown-menu">
                    <li><a href="#">Projects</a></li>
                    <li><a href="#">Task</a></li>
                    <li><a href="#">User</a></li>
                    <li class="divider"></li>
                    <li><a href="#">Email</a></li>
                </ul>
            </li>
        </ul>
    </div>
    <!-- left navigation end -->

    <!-- right navigation start -->
    <div class="pull-right">
        <ul>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                    <i class="material-icons mi-22">notifications_none</i>
                </a>

                <ul class="dropdown-menu notifications">
                    <li class="head">
                        <a href="#">
                            <strong>You have 2 notifications</strong>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            Awesome aminmate.css
                            <small>10 mint ago</small>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            Ionicons font aminmate.css
                            <small>1 hous ago</small>
                        </a>
                    </li>

                    <li class="divider"></li>

                    <li>
                        <a href="#">
                            <span>See all notifications</span>
                            <i class="material-icons mi-16 pull-right">settings</i>
                        </a>
                    </li>
                </ul>
            </li>

            <li><a href="<?php echo e(url('admin/settings')); ?>"><i class="material-icons mi-20">settings</i></a></li>

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <i class="material-icons mi-23">person</i>
                </a>

                <ul class="dropdown-menu user">
                    <li class="head">
                        <a href="#">
                            <strong><?php echo e(ucwords(Auth::user()->name)); ?></strong>
                            <small><?php echo e(Auth::user()->email); ?></small>
                        </a>
                    </li>

                    <li><a href="<?php echo e(url('admin/registration')); ?>">Create New</a></li>
                    <li><a href="<?php echo e(url('admin/registration/change/'.Auth::user()->id)); ?>">Settings</a></li>

                    <li>
                        <a href="#">
                            Profile
                            <span class="badge pull-right">30%</span>
                        </a>
                    </li>

                    <li><a href="#">Help</a></li>
                    <li class="divider"></li>
                    <li><a href="<?php echo e(url('admin/logout')); ?>">Logout</a></li>
                </ul>
            </li>
        </ul>
    </div>
    <!-- right navigation end -->

</nav>
<!-- main navigation end -->
