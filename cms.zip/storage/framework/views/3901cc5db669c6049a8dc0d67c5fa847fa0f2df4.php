<?php $__env->startSection('content'); ?>
<style type="text/css" media="screen">
    .btn{
        margin-left: 0px;
    }
    .gallery{
        margin-top: 25px;
    }
	.theme-thumbnail{
		position: relative;
		width: 100%;
		height: 280px;
		overflow: hidden;
		margin-bottom: 5px;
		border: 5px solid #fff;
		border-radius: 3px;
	}
	.theme-thumbnail .img-thumbnail{
		width: 100%;
		height: auto;
		border: 0;
		padding: 0;
		border-radius: 0;
	}
	.theme-active:after{
		position: absolute;
		content:"Activeted";
		left: -48px;
		top: 24px;
		width: 180px;
		height: 36px;
		padding: 6px 10px;
		transform: rotate(-45deg);
		background: #5cb85c;
		text-align: center;
		font-weight: bolder;
		color: #ffffff;
		z-index: 3;
	}
</style>
<div class="<?php echo e(isset($width) ? $width : 'container'); ?>">
    <div class="row">
        <div class="col-md-12">

            <!-- alert message start -->
            <?php echo session('success'); ?>

            <!-- alert message end -->

            <div class="col-md-12 gallery" >
                <div class="row">
                    <?php $__currentLoopData = $allTheme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="col-md-3 gallery-image" style="">
                        <span><?php echo e($theme->title); ?></span>
                        <div class="theme-thumbnail <?php echo e((isset($current->value) && $theme->id==$current->value) ? "theme-active" : ""); ?>"><img src="<?php echo e(asset($theme->thumb)); ?>" alt="" class="img-thumbnail"></div>
                        <a href="<?php echo e(url("admin/company/set_theme/".$theme->id)); ?>" class="btn btn-success btn-block">Active This Theme</a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.app', ['page' => 'company-theme'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>