<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e($title); ?> | <?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- google font -->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">

        <!-- include custom stylesheet -->
        <link href="<?php echo e(asset('public/admin/css/credential.css')); ?>" rel="stylesheet">

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>

        <!-- wrapper section start -->
        <section class="wrapper">

            <!-- aside container start -->
            <div class="column aside">
                <div class="credential">

                    <!-- brand infomation section start -->
                    <figure>
                        <img src="<?php echo e(asset('public/admin/imgs/logos/logo.png')); ?>" alt="company logo">

                        <figcaption>
                            <strong>CMS</strong>
                            
                        </figcaption>
                    </figure>
                    <!-- brand infomation section end -->

                    <!-- form section start -->
                    <?php echo $__env->yieldContent('credential'); ?>
                    <!-- form section end -->

                    <!-- link section start -->
                    <div class="bottom">
                        <?php $__env->startSection('link'); ?>
                            <a href="<?php echo e(url('/')); ?>">Home</a>
                            <a href="<?php echo e(route('admin.password.request')); ?>">Forgot Your Password?</a>
                        <?php echo $__env->yieldSection(); ?>
                    </div>
                    <!-- link section end -->

                    <!-- alert message start -->
                    <?php echo $__env->yieldContent('alert'); ?>
                    <!-- alert message end -->
                </div>
            </div>
            <!-- aside container end -->

            <!-- article container start -->
            <div class="column article">
                <article class="">
                    

                    <p style="font-size: 20px;">
                        Welcome to the <?php echo e(env("APP_NAME")); ?> admin panel. This panel is provided by US IT Solution. Any updates/changes made through this panel is solely for the <?php echo e(env("APP_NAME")); ?> business. Only the authorized personal should be the admin to this account. <?php echo e(env("APP_NAME")); ?> is responsible to upgrade and maintain the panel for the plugins unless there are other arrangements exist. User documentation is available if needed. 
                    </p>
                </article>
            </div>
            <!-- article container end -->
        </section>
        <!-- wrapper section end -->

        <script type="text/javascript">
            localStorage.removeItem("state");
            localStorage.removeItem("status");
            localStorage.removeItem("width");
            localStorage.removeItem("counter");
        </script>

    </body>
</html>
