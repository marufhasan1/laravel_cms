<?php $__env->startPush("meta"); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush("scripts"); ?>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
	<h1> This is Home page </h1>
	<a href="<?php echo e(url("login")); ?>">Login</a>
	<a href="<?php echo e(url("register")); ?>">Register</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>