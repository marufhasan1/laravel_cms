<!DOCTYPE html>
<html lang="en">
<head>    
    <title><?php echo e($info->company_name); ?></title>
    <link rel="icon" href="images/resources/favicon.png" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="#">
    <meta name="description" content="#">
    <meta name="robots" content="index, follow">
    <meta name="author" content="">
    <?php echo $__env->yieldPushContent('meta'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("public/theme/".$theme."/vendors/bootstrap/css/bootstrap.min.css")); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("public/theme/".$theme."/vendors/font-awesome/css/font-awesome.min.css")); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("public/theme/".$theme."/style.css")); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("public/theme/".$theme."/css/responsive.css")); ?>">
    <?php echo $__env->yieldPushContent('style'); ?>
</head>
    

<body>
    
</body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>                        
          </button>
          <a class="navbar-brand text-light" href="#"><?php echo e($info->company_name); ?></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#contact">Contact us</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <?php echo $__env->yieldContent("content"); ?>;

    <footer class="main-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4"> 
                    <p class="company-branding">Powered By: <a href="https://usitsolution.net/">US IT Solution LLC</a></p> 
                </div>
                <div class="col-md-4">
                    <ul class="footer-user-link">
                        <li><a href="">Home</a></li>
                        <li><a href="">About</a></li>
                        <li><a href="">Company</a></li>
                        <li><a href="">Portfolio</a></li>
                        <li><a href="">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="social-link">
                        <li><a href=""> <i class="fa fa-facebook"></i> </a></li>
                        <li><a href=""> <i class="fa fa-twitter"></i> </a></li>
                        <li><a href=""> <i class="fa fa-instagram"></i> </a></li>
                        <li><a href=""> <i class="fa fa-linkedin"></i> </a></li>
                        <li><a href=""> <i class="fa fa-youtube"></i> </a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <!-- external file adding -->
    <script type="text/javascript" src="<?php echo e(asset("public/theme/".$theme."/js/jquery-3.3.1.min.js")); ?>"> </script>
    <script type="text/javascript" src="<?php echo e(asset("public/theme/".$theme."/vendors/bootstrap/js/bootstrap.min.js")); ?>"> </script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>
</html>