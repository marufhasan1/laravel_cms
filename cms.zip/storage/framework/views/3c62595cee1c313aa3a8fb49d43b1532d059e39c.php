<ul class="pull-left" role="<?php echo e($role); ?>">
    <li data-label="company-add"><a href="<?php echo e(url('admin/company')); ?>">Add Company</a></li>
    <li data-label="company-all"><a href="<?php echo e(url('admin/company/all')); ?>">All Company</a></li>
</ul>