<?php $__env->startSection('content'); ?>
<div class="<?php echo e(isset($width) ? $width : 'container'); ?>" >

    <!-- alert message start -->
    <?php if(session('alert')): ?>
        <?php echo session('alert'); ?>

    <?php endif; ?>
    <!-- alert message end -->


    <div class="row">
        <div class="col-md-12">

            <!-- alert message start -->
            <?php echo session('success'); ?>

            <!-- alert message end -->
            <table class="table">
            	<thead>
            		<tr>
            			<th>SL</th>
            			<th>Name</th>
            			<th>URL</th>
                        <th>Contact Number</th>
            			<th>Status</th>
            			<th>Action</th>
            		</tr>
            	</thead>

            	<tbody>
                    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($row->company_name); ?></td>
                        <td>
                            <a target="_blank" href="http://<?php echo e($row->site_url.".".config("app.domain")); ?>"><?php echo e($row->site_url.".".config("app.domain")); ?></a>
                        </td>
                        <td><a href="tel:<?php echo e($row->contact_number); ?>"><?php echo e($row->contact_number); ?></a></td>
                        <td><?php echo e($row->status); ?></td>
                        <td>
                            <a href="<?php echo e(url("admin/company/edit/".$row->id)); ?>" class="btn btn-primary">Update</a>
                            <a onclick="return confirm('Are you sure to delete this Company?')" href="<?php echo e(url("admin/company/delete_company/".$row->id)); ?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.master.app', ['page' => 'company-all'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>