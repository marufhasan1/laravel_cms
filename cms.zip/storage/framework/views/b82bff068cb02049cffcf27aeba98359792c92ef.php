<ul class="pull-left" role="<?php echo e($role); ?>">
    <li data-label="dashboard"><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
</ul>
