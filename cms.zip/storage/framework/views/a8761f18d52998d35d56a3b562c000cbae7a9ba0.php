<div class="head" role="<?php echo e($role); ?>">
    <div class="<?php echo e($width); ?>">
        <div class="row">
            <div class="col-md-12">

                <!-- breadcrumb start -->
                <?php echo $__env->make('backend.master.head.breadcrumb', ['role' => 'breadcrumb'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- breadcrumb end -->

                <!-- section navigation start -->
                <nav class="submenu" data-page="<?php echo e($page); ?>">
                    <!-- left side navigation start -->
                    <?php echo $__env->make($nav, ['role' => 'submenu'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!-- left side navigation end -->

                    <!-- right side navigation start -->
                    <?php if(isset($help)): ?>
                    <!-- <ul class="pull-right">
                        <?php if(isset($help['instruction'])): ?>
                            <li data-label="instruction"><a href="<?php echo e(route($help['instruction'])); ?>">Instruction</a></li>
                        <?php endif; ?>

                        <?php if(isset($help['video'])): ?>
                            <li><a href="#" id="tutorial" data-target="<?php echo e($help['video']); ?>">Video</a></li>
                        <?php endif; ?>

                        <?php if(isset($help['print'])): ?>
                            <li><a href="#" id="print" data-target="<?php echo e($help['print']); ?>">Print</a></li>
                        <?php endif; ?>
                    </ul> -->
                    <?php endif; ?>
                    <!-- right side navigation end -->
                </nav>
                <!-- section navigation end -->

            </div>
        </div>
    </div>
</div>
