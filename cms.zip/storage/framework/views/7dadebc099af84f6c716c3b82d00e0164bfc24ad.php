<?php $__env->startSection('content'); ?>
<style type="text/css" media="screen">
    .gallery{
        margin-top: 70px;
    }
    .gallery .gallery-image{
        margin-bottom: 25px;
        min-width: 295px;
        min-height: 162px;
    }
    .gallery .gallery-image .img-thumbnail{
        border-radius: 0px;
    }
    .btn{
        margin-left: 0px
    }
</style>
<div class="<?php echo e(isset($width) ? $width : 'container'); ?>" ng-controller="ProductCtrl">
    <div class="row">
        <div class="col-md-12">

            <!-- alert message start -->
            <?php echo session('success'); ?>

            <!-- alert message end -->

            <form method="POST" action="" enctype="multipart/form-data" class="form-horizontal ng-pristine ng-valid">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="username" class="col-sm-2 control-label">Gallery Image</label>

                    <div class="col-sm-10">
                        <input type="file" name="image" value="" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <div class="pull-left">
                            <button type="submit" class="btn btn-success">Update</button>
                        </div>
                    </div>
                </div>
            </form>

        </div>
        <div class="col-sm-offset-2 col-md-10 gallery" >
            <div class="row">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 gallery-image" style="">
                    <img src="<?php echo e(asset("storage/app/".$image->upload_path)); ?>" alt="" class="img-responsive img-thumbnail">
                    <a onclick="return confirm('Are you sure to delete this image?')" href="<?php echo e(url("admin/company/delete_gallery/".$image->id)); ?>" class="btn btn-danger btn-block">Delete</a>
                </div>                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.app', ['page' => 'company-gallery_image'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>