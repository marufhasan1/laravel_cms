<?php $__env->startSection('content'); ?>
<style type="text/css" media="screen">
    .btn{
        margin-left: 0px
    }
    .img-thumbnail{
        border-radius: 0px;
    }
</style>
<div class="<?php echo e(isset($width) ? $width : 'container'); ?>" ng-controller="ProductCtrl">
    <div class="row">
        <div class="col-md-12">

            <!-- alert message start -->
            <?php echo session('success'); ?>

            <!-- alert message end -->
            <form method="POST" action="" enctype="multipart/form-data" class="form-horizontal ng-pristine ng-valid">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="old_banner" value="<?php echo e(isset($info->company_uploades[0]) ? $info->company_uploades[0]->upload_path : "N/A"); ?>">
                <div class="form-group">
                    <label for="fullname" class="col-sm-2 control-label">Company Name</label>

                    <div class="col-sm-10">
                        <input type="text" name="company_name" value="<?php echo e($info->company_name); ?>" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <label for="sub_title" class="col-sm-2 control-label">Sub Title</label>

                    <div class="col-sm-10">
                        <input type="text" name="subtitle" value="<?php echo e(isset($info->company_meta[0]) ? $info->company_meta[0]->meta_value : "N/A"); ?>" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <label for="username" class="col-sm-2 control-label">Header Image</label>

                    <div class="col-sm-10">
                        <input type="file" name="banner" value="" class="form-control">
                    </div>
                </div>
                
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-5">
                        <?php if(isset($info->company_uploades[0])): ?>
                            <img src="<?php echo e(asset("storage/app/".$info->company_uploades[0]->upload_path)); ?>" alt="" class="img-responsive img-thumbnail">
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <div class="pull-left">
                            <button type="submit" name="update" class="btn btn-success">Update</button>
                        </div>
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.app', ['page' => 'company-header'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>