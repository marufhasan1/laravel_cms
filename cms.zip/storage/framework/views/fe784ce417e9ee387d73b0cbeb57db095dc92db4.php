<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('public/admin/ckeditor/ckeditor.js')); ?>"></script>
<style type="text/css" media="screen">
    .btn{
        margin-left: 0px;
    }
</style>
    <div class="<?php echo e(isset($width) ? $width : 'container'); ?>" ng-controller="ProductCtrl">
        <div class="row">
            <div class="col-md-12">

                <!-- alert message start -->
                <?php echo session('success'); ?>

                <!-- alert message end -->
                
                <form method="POST" action="" enctype="multipart/form-data" class="form-horizontal ng-pristine ng-valid">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="old_image" value="<?php echo e(isset($about_image->upload_path) ? $about_image->upload_path : ""); ?>">
                    <div class="form-group">
                        <div class="col-sm-12">
                            <textarea id="editor" name="about_company" class="form-control"><?php echo e(isset($info->meta_value) ? $info->meta_value : ""); ?></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="image" class="col-sm-2 control-label">About Image</label>

                        <div class="col-sm-10">
                            <input type="file" id="image" name="about_image" value="" class="form-control">
                        </div>
                    </div>
                
                    <div class="form-group">
                        <div class="col-sm-10">
                            <div class="pull-left">
                                <button type="submit" class="btn btn-success">Update</button>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-5">
                            <?php if(isset($about_image->upload_path)): ?>
                                <img src="<?php echo e(asset("storage/app/".$about_image->upload_path)); ?>" alt="" class="img-responsive img-thumbnail">
                            <?php endif; ?>
                        </div>
                    </div>

                </form>

            </div>
        </div>
    </div>
<script>
    CKEDITOR.replace("editor");
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.app', ['page' => 'company-about_company'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>