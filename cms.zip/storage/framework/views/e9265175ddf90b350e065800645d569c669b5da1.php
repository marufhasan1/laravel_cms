<?php $__env->startSection('content'); ?>
<div class="<?php echo e(isset($width) ? $width : 'container'); ?>">
    <div class="row">
        <div class="col-md-12">



             



       


        </div>
    </div>


    <div class="row">
        <h2 class="text-center">Welcome to the dashboard</h2>
        <div class="col-md-3 col-sm-6 col-xs-6">
            <a href="<?php echo e(url('admin/message')); ?>">
                <div class="widgets">
                    <div class="icons"> <i class="material-icons mi-16">mail</i> </div>
                    <label>Message</label>
                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
            <a href="<?php echo e(url('admin/product/add-new')); ?>">
                <div class="widgets">
                    <div class="icons"> <i class="material-icons"> add </i> </div>
                    <label>Add new product</label>
                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
            <a href="<?php echo e(url('admin/product/list')); ?>">
                <div class="widgets">
                    <div class="icons"> <i class="material-icons"> list </i></div>
                    <label>Modify your existing product's</label>
                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
            <a href="<?php echo e(url('admin/theme/new_arrival')); ?>">
                <div class="widgets">
                    <div class="icons"> <i class="material-icons"> new_releases </i> </div>
                    <label>New arrival</label>
                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
            <a href="<?php echo e(url('admin/theme/product_banner')); ?>">
                <div class="widgets">
                    <div class="icons"> <i class="material-icons"> art_track</i></div>
                    <label>Add/Modify Banner (Brand/Category)</label>
                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
            <a>
                <div class="widgets">
                    <div class="icons"> <i class="material-icons"> video_label </i> </div>
                    <label>Share video</label>
                    <div class="multi_link">
                        <a class="btn btn-primary" href="<?php echo e(url('admin/video/home_page')); ?>">Home</a>
                        <a class="btn btn-primary" href="<?php echo e(url('admin/video/why_us')); ?>">Why us</a>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>

<style>
    a{
        displa: block;
    }
    .widgets{
        width: 100%;
        height: 160px;
        border-radius: 5px;
        background-color: #f0f0f0;
        border: 1px solid #999999;
        margin: 15px auto;
        text-align: center;
        box-sizing: border-box;
        padding: 15px;
        position: relative;
        overflow: hidden;
    }
    .widgets .icons i{
        font-size: 78px;
    }
    .widgets .multi_link{
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(255,255,255,0.95);
        text-align: center;
        padding: 18px 0;
        transition: ease 0.3s;
        transform: scale(1.2,1.2);
        opacity: 0;
    }
    .widgets .multi_link a{
        display: block;
        width: 85%;
        margin: 10px auto;
        padding: 5px 25px;
        border-radius: 5px;
        font-weight: 600;
    }
    .widgets:hover .multi_link{
        opacity: 1;
        transform: scale(1,1);
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.app', ['page' => 'dashboard'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>