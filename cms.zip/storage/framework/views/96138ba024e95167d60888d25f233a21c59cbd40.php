<?php $__env->startSection('credential'); ?>
<form method="POST" action="<?php echo e(route('admin.login.submit')); ?>">
    <strong>Sign In</strong>

    <?php echo e(csrf_field()); ?>


    <div class="<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <label for="">
            <input type="email" name="email" placeholder="E-Mail Address" value="<?php echo e(old('email')); ?>" required autofocus>
        </label>

        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>
    </div>

    <div class="<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
        <label for="">
            <input type="password" name="password" placeholder="Password" required>
        </label>

        <?php if($errors->has('password')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
        <?php endif; ?>
    </div>

    <div class="remember">
        <label>
            <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
            Remember me
        </label>
    </div>

    <div class="">
        <button type="submit">Sign In</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master.authentication', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>