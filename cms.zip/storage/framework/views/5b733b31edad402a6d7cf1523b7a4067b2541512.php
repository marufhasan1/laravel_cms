<?php $__env->startSection('content'); ?>
    <section class="account">
        <div class="container">
            <div class="row">
                <div class="account-form">
                    <h4 class="section-title">Register Now</h4>
                    

                    <form class="pt-3" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <div class="form-wrapper">
                                <input type="text" class="form-input form-input-l" name="first_name" value="<?php echo e(old('first_name')); ?>" placeholder="First Name" required autofocus>

                                <input type="text" class="form-input form-input-r" name="last_name" value="<?php echo e(old('last_name')); ?>" placeholder="Last Name" required autofocus>
                            </div>

                            <?php if($errors->has('first_name')): ?>
                                <p class="msg-alert"><em><?php echo e($errors->first('first_name')); ?></em></p>
                            <?php endif; ?>

                            <?php if($errors->has('last_name')): ?>
                                <p class="msg-alert"><em><?php echo e($errors->first('last_name')); ?></em></p>
                            <?php endif; ?>
                        </div>

                        <div class="<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <input type="email" class="form-input" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email Address" required>

                            <?php if($errors->has('email')): ?>
                                <p class="msg-alert"><em><?php echo e($errors->first('email')); ?></em></p>
                            <?php endif; ?>
                        </div>

                        <div class="<?php echo e($errors->has('phone_number') ? ' has-error' : ''); ?>">
                            <input type="text" class="form-input" name="phone_number" value="<?php echo e(old('phone_number')); ?>" placeholder="Phone No" required>

                            <?php if($errors->has('phone_number')): ?>
                                <p class="msg-alert"><em><?php echo e($errors->first('phone_number')); ?></em></p>
                            <?php endif; ?>
                        </div>

                        <div class="<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <input type="password" class="form-input" id="password" name="password" placeholder="Type Password" required>

                            <?php if($errors->has('password')): ?>
                                <p class="msg-alert">
                                    <em><?php echo e($errors->first('password')); ?></em>
                                </p>
                            <?php endif; ?>
                        </div>

                        <input type="password" class="form-input" name="password_confirmation" placeholder="Re-Type Password" required>

                        <div>
                            <button type="submit" class="btn btnSubmit">Register Now</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', ['page' => 'index', 'search' => false], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>