<?php $__env->startSection('content'); ?>
    <?php 
        $banner_path = "public/theme/".$theme."/images/resources/pc-bg.jpg";
        $about_image = "https://cityscapeillustrator.com/wp-content/uploads/2018/01/nyc.jpg";
        
        if(isset($info->company_uploades["banner"])){
            $banner_path = asset("storage/app/".$info->company_uploades["banner"]);
        }

        if(isset($info->company_uploades["about_image"])){
            $about_image = asset("storage/app/".$info->company_uploades["about_image"]);
        }
        
     ?>
    <header class="index-header" style="background-image: url(<?php echo e($banner_path); ?>);">
        <div class="container">
            <div class="col-md-12">
                <div class="text-box">
                    <h1 class="header-title"><?php echo e($info->company_name); ?></h1>
                    <p class="header-slogan"><?php echo e(isset($info->company_meta["subtitle"]) ? $info->company_meta["subtitle"] : config("myconfig.default.sub_title")); ?></p>
                    <a class="btnHdr" href="#contact">Contact Now</a>
                </div>
            </div>
        </div>
    </header>


    <section class="about-company">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <h2 class="section-title">What's We Really Do?</h2>
                    <p class="text-dark">
                        <?php echo isset($info->company_meta["about_company"]) ? $info->company_meta["about_company"] : config("myconfig.default.about_company"); ?>

                    </p>
                </div>
                <div class="col-md-12 col-sm-12">
                    <img class="img-responsive" src="<?php echo e($about_image); ?>" alt="#">
                </div>
            </div>
        </div>
    </section>


    <section class="service-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="section-title">Gallery</h2>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $gallery_image->company_uploades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-4 col-xs-12" style="margin-top: 10px;">
                    <div class="service-block">
                        <img class="img-responsive" src="<?php echo e(asset("storage/app/".$element->upload_path)); ?>" alt="">
                        
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                               
            </div>
        </div>
    </section>


    <section class="contatc-area"> 
        <div class="container">
            <div class="row">
                <div class="col-md-12"> <h2 class="section-title">Contact With Us</h2> </div>
            </div>
            <div class="row">
                <div class="col-md-4 "> 
                    <div class="contact-card">
                        <a href="tel:<?php echo e($info->contact_number); ?>" class="phone">
                            <span>CALL NOW</span> <span class="phone-no"><?php echo e($info->contact_number); ?></span>
                        </a>

                        <div class="location">
                            <p class="lead"><i class="fa fa-map-marker" aria-hidden="true"></i>  Our Address</p>
                            <p class="text-address">
                                <?php echo e($info->street_number." ".$info->route); ?> <br>
                                <?php echo e($info->city.", ".$info->state); ?> <br>
                                <?php echo e($info->zipcode.", ".$info->country); ?> <br>
                            </p>
                        </div>                        
                        <div class="location">
                            <p class="lead"><i class="fa fa-calendar" aria-hidden="true"></i> Business Hours</p>
                            <table class="business-time">
                                <tr>
                                    <td>Mon:</td>
                                    <td>8:00 AM – 11:00 PM</td>
                                </tr>                                
                                <tr>
                                    <td>Tue:</td>
                                    <td>8:00 AM – 11:00 PM</td>
                                </tr>                                
                                <tr>
                                    <td>Wed:</td>
                                    <td>8:00 AM – 11:00 PM</td>
                                </tr>                                
                                <tr>
                                    <td>Thu:</td>
                                    <td>8:00 AM – 11:00 PM</td>
                                </tr>                                
                                <tr>
                                    <td>Fri:</td>
                                    <td>8:00 AM – 12:00 PM</td>
                                </tr>                                
                                <tr>
                                    <td>Sat:</td>
                                    <td>8:00 AM – 12:00 PM</td>
                                </tr>                                
                                <tr>
                                    <td>Sun:</td>
                                    <td>9:00 AM – 11:00 PM</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-8"> 
                    <iframe src="<?php echo e(isset($info->company_meta["map_source"]) ? $info->company_meta["map_source"] : config("myconfig.default.map")); ?>" width="100%" height="480" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.'.$theme.'.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>