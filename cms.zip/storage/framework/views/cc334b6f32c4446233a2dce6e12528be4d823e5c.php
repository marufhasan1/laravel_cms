<?php $__env->startSection('content'); ?>
<?php 
    $banner_path = "public/theme/".$theme."/images/banner.jpg";
    $about_image = "public/theme/".$theme."/images/company.jpg";
    
    if(isset($info->company_uploades["banner"])){
        $banner_path = asset("storage/app/".$info->company_uploades["banner"]);
    }

    if(isset($info->company_uploades["about_image"])){
        $about_image = asset("storage/app/".$info->company_uploades["about_image"]);
    }
    
 ?>

<!-- banner section -->
    <div id="banner" style="background-image: url(<?php echo e(asset($banner_path)); ?>);">
        <div class="container-fluid">
            <div class="banner-text text-light text-center">
                <h1 class="display-4 font-weight-bold"><?php echo e($info->company_name); ?></h1>
                <h4 class="py-2"><?php echo e(isset($info->company_meta["subtitle"]) ? $info->company_meta["subtitle"] : config("myconfig.default.sub_title")); ?></h4>
                <a href="#contact" class="btn btn-info px-5 py-3 mt-3">Contact Now</a>
            </div>
        </div>
    </div>
<!-- end banner section -->




<!-- about section -->
<div id="about">
    <div class="container">
        <div class="row mt-5">
            <div class="col-md-6">
                <div class="about-image">
                    <img class="w-100 mt-5 bg-info p-1 img-fluid" src="<?php echo e(asset($about_image)); ?>" alt="company images">
                </div>
            </div>
            <div class="col-md-6 mt-5">
                <div class="about-content">
                    <h2 class="font-weight-bold">About Company</h2>
                    <div class="border my-2"></div>
                    <p class="lead text-justify"><?php echo isset($info->company_meta["about_company"]) ? $info->company_meta["about_company"] : config("myconfig.default.about_company"); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end about section -->



<!-- service section -->
<div id="service">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="service-title pt-2">
                    <h1 class="mt-5 text-center font-weight-bold">Gallery</h1>
                    <div class="text-b mb-4"></div>
                </div>
            </div>
        </div>
        <div class="row">

            <?php $__currentLoopData = $gallery_image->company_uploades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-4 pb-4">
                <div class="img-service">
                    <img class="img-fluid img-thumbnail shadow" src="<?php echo e(asset("storage/app/".$element->upload_path)); ?>" alt="">
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
<!-- end service section -->





<!-- contact section -->
<div id="contact">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="service-title pt-2">
                    <h1 class="mt-5 text-center font-weight-bold">Contact with us</h1>
                    <div class="text-b mb-4"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="contact-card shadow p-3">
                    <a href="tel:<?php echo e($info->contact_number); ?>" class="phone">
                        <span>CALL NOW</span> <span class="phone-no"><?php echo e($info->contact_number); ?></span>
                    </a>
                
                    <div class="location" style="padding-top: 43px;">
                        <p class="lead"><i class="fa fa-map-marker" aria-hidden="true"></i> Our Address</p>
                        <p class="text-address">
                            <?php echo e($info->street_number." ".$info->route); ?> <br>
                            <?php echo e($info->city.", ".$info->state); ?> <br>
                            <?php echo e($info->zipcode.", ".$info->country); ?> <br>
                        </p>
                    </div>
                    <div class="location">
                        <p class="lead"><i class="fa fa-calendar" aria-hidden="true"></i> Business Hours</p>
                        <table class="table table-striped table-bordered table-sm">
                            <tr>
                                <td>Mon:</td>
                                <td>8:00 AM – 11:00 PM</td>
                            </tr>
                            <tr>
                                <td>Tue:</td>
                                <td>8:00 AM – 11:00 PM</td>
                            </tr>
                            <tr>
                                <td>Wed:</td>
                                <td>8:00 AM – 11:00 PM</td>
                            </tr>
                            <tr>
                                <td>Thu:</td>
                                <td>8:00 AM – 11:00 PM</td>
                            </tr>
                            <tr>
                                <td>Fri:</td>
                                <td>8:00 AM – 12:00 PM</td>
                            </tr>
                            <tr>
                                <td>Sat:</td>
                                <td>8:00 AM – 12:00 PM</td>
                            </tr>
                            <tr>
                                <td>Sun:</td>
                                <td>9:00 AM – 11:00 PM</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-8 mb-5">
                <map name="">
                    <iframe
                        src="<?php echo e(isset($info->company_meta["map_source"]) ? $info->company_meta["map_source"] : config("myconfig.default.map")); ?>"
                        width="100%" height="500" frameborder="0" style="border:0" allowfullscreen></iframe>
                </map>
            </div>
        </div>
    </div>
</div>
<!-- end contact section -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.'.$theme.'.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>