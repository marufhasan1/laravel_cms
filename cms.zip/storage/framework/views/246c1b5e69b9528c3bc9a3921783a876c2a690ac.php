<!DOCTYPE html>
    <html lang="en">
    <head>    
        <title>CMS</title>
        <?php echo $__env->yieldPushContent("meta"); ?>
        <?php echo $__env->yieldPushContent("style"); ?>
    </head>

    <body>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->yieldPushContent("scripts"); ?>
    </body>
</html>
