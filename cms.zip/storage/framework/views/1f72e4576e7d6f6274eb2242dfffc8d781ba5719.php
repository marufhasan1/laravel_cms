<!-- app aside section end -->
<div class="column aside" data-menu="<?php echo e($menu); ?>" data-submenu="<?php echo e(($active != '') ? $active : 'none'); ?>">

    <!-- brand section start -->
    <div class="brand">
        <a href="<?php echo e(url('admin')); ?>"><strong><?php echo e(env("APP_NAME")); ?></strong></a>
        <i class="material-icons mi-18" id="aside-close">close</i>
    </div>
    <!-- brand section end -->

    <!-- aside navigation start -->
    <nav class="aside-container">
        <h5>Navigation</h5>

        <ul>
            <li id="dashboard">
                <a href="<?php echo e(url('admin')); ?>">
                    <i class="material-icons mi-16">dashboard</i>
                    <span>Dashboard</span>
                </a>
            </li>

            <li id="message">

                <a href="<?php echo e(url('admin/message')); ?>">
                    <i class="material-icons mi-16">mail</i>
                    <span>Message</span>
                    <span class="badge blue pull-right"></span>
                </a>
            </li>
        </ul>

        <h5>Modules</h5>

        <ul>


            <li id="company" class="dropdown">
                <a href="#" data-target="theme-menu">
                    <i class="material-icons mi-24">list</i>
                    <span>Company</span>

                    <span class="pull-right">
                        <i class="material-icons right mi-18">keyboard_arrow_right</i>
                        <i class="material-icons down mi-18">keyboard_arrow_down</i>
                    </span>
                </a>

                <ul id="theme-menu">
                    <li id="theme-new_arrival"><a href="<?php echo e(url('admin/company')); ?>">Add New</a></li>
                    <li id="theme-product_banner"><a href="<?php echo e(url('admin/company/all')); ?>">All Companies</a></li>
                </ul>
            </li>


        </ul>

    </nav>
    <!-- aside navigation end -->

</div>
<!-- app aside section end -->
