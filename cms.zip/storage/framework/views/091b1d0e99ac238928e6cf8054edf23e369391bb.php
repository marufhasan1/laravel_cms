<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" ng-app="Mainapp">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(ucwords(str_replace('-', ' ', $menu))); ?> | <?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- google font -->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700" rel="stylesheet">

        <!-- include bootstrap stylesheet -->
        <link href="<?php echo e(asset('public/admin/vendors/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

        <!-- include themify icons -->
        <link href="<?php echo e(asset('public/admin/vendors/themify/themify-icons.css')); ?>" rel="stylesheet">

        <!-- include custom stylesheet -->
        <link href="<?php echo e(asset('public/admin/css/master.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('public/admin/css/print.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('public/admin/css/timepicker.css')); ?>" rel="stylesheet">
        <?php echo $__env->yieldPushContent('style'); ?>

        <!-- include angularjs -->
        <script type="text/javascript" src="<?php echo e(asset('public/admin/vendors/angular/angular.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('public/admin/vendors/angularUtils/src/directives/pagination/dirPagination.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('public/admin/js/app.js')); ?>"></script>

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>

        <!-- preloader start -->
        <?php if(!$developer_mode): ?>
        <div id="preloader">
            <div id="status">&nbsp;</div>
        </div>
        <?php endif; ?>
        <!-- preloader end -->

        <!-- wrapper section start -->
        <section class="wrapper <?php echo e(isset($aside) ? $aside : ''); ?>">

            
            <?php echo $__env->make('backend.master.aside', ['menu' => $menu], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- app body section start -->
            <div class="column body">
                
                <?php echo $__env->make('backend.master.navigation', ['role' => "navigation"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <!-- main body start -->
                <div class="body-container">

                    <!-- body head start -->
                    <?php echo $__env->make('backend.master.head', ['role' => 'head'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!-- body head end -->

                    <!-- body content start -->
                    <div class="content">

                        <!-- error or warning message section start -->
                        <div class="<?php echo e(isset($width) ? $width : 'container'); ?>">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-warning alert-dismissible" role="alert">
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>

                                            <strong>Warning!</strong>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p><?php echo e($error); ?></p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <!-- error or warning message section end -->

                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                    <!-- body content end -->

                    <!-- app footer section start -->
                    <div class="footer">&nbsp;</div>
                    <!-- app footer section end -->
                </div>
                <!-- main body end -->
            </div>
            <!-- app body section end -->
        </section>
        <!-- wrapper section end -->

        <!-- video section start -->
        <?php if(isset($help['video'])): ?>
        <div class="tutorial">
            <div class="">
                
                <iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/oxtP3wxXlTA?rel=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
            </div>
        </div>
        <?php endif; ?>
        <!-- video section end -->

        <!-- layer start -->
        <span class="wrapper-background"></span>
        <!-- layer end -->

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        
        <script src="<?php echo e(asset('public/admin/vendors/jQuery/jquery-3.1.1.min.js')); ?>"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="<?php echo e(asset('public/admin/vendors/bootstrap/js/bootstrap.min.js')); ?>"></script>
        <!-- include nicescroll -->
        <script src="<?php echo e(asset('public/admin/vendors/jquery.nicescroll/jquery.nicescroll.min.js')); ?>"></script>
        <!-- include custom javascript files -->
        <script src="<?php echo e(asset('public/admin/js/system.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('public/admin/js/timepicker.js')); ?>" type="text/javascript"></script>
        <?php echo $__env->yieldPushContent('scripts'); ?>

    </body>
</html>
