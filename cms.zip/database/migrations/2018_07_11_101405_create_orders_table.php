<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('restaurant_id');
            $table->string('order_type', 45)->default('pending')->comment("default is pending and other is delivered");
            $table->date('request_date')->format("Y-m-d");
            $table->time('request_time')->format("H:m:i");
            $table->text('special_instraction', 45)->nullable();
            $table->decimal('subtotal', 10, 2);
            $table->decimal('tax', 10, 2);
            $table->string('status', 45);
            $table->timestamps();
        });

        if (Schema::hasTable('orders')) {
            Schema::create('order_details', function (Blueprint $table) {
                $table->increments('id');
                $table->integer('order_id')->unsigned();
                $table->integer('item_id')->unsigned();
                $table->string('item');
                $table->decimal('item_price', 10, 2);
                $table->integer('item_quantity');
                $table->text('special_instraction', 45)->nullable();
                $table->foreign('order_id')->references('id')->on('orders')->onUpdate('cascade')->onDelete('cascade');
            });

            Schema::create('customer_information', function (Blueprint $table) {
                $table->increments('id');
                $table->integer('order_id')->unsigned();
                $table->integer('customer_id')->unsigned();
                $table->string('customer_name')->nullable();
                $table->string('phone_number', 45);
                $table->text('delivery_address');
                $table->foreign('order_id')->references('id')->on('orders')->onUpdate('cascade')->onDelete('cascade');
            });

            Schema::create('payment_information', function (Blueprint $table) {
                $table->increments('id');
                $table->integer('order_id')->unsigned();
                $table->string('cart_number', 45);
                $table->string('auth_code', 45)->comment("from api response");
                $table->string('trans_id', 45)->comment("from api response");
                $table->foreign('order_id')->references('id')->on('orders')->onUpdate('cascade')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payment_information');
        Schema::dropIfExists('customer_information');
        Schema::dropIfExists('order_details');
        Schema::dropIfExists('orders');
    }
}
