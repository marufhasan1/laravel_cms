<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAddressesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addresses', function (Blueprint $table) {
            $table->increments('id');
            $table->string('street');
            $table->string('city');
            $table->string('state')->nullable();
            $table->string('zipcode');
            $table->string('country');
            $table->string('restaurant');
            $table->string('tag_name');
            $table->string('contact_details');
            $table->decimal('tax', 10, 2);
            $table->string('latitude');
            $table->string('longitude');
            $table->string('image')->nullable();
            $table->string('status')->default('open')->comment('open or close. default value is open');
            $table->boolean('trash')->default(false);
            $table->timestamps();
        });

        if (Schema::hasTable('addresses')) {
            Schema::create('menus', function (Blueprint $table) {
                $table->increments('id');
                $table->integer('address_id')->unsigned();
                $table->string('category');
                $table->string('group');
                $table->string('item');
                $table->text('description');
                $table->decimal('price', 8, 2);
                $table->string('path')->nullable();
                $table->string('status', 45);
                $table->foreign('address_id')->references('id')->on('addresses')->onUpdate('cascade')->onDelete('cascade');
            });
        }

        if (Schema::hasTable('addresses')) {
            Schema::create('restaurant_meta', function (Blueprint $table) {
                $table->increments('id');
                $table->integer('address_id')->unsigned();
                $table->string('meta_key');
                $table->text('meta_value');
                $table->foreign('address_id')->references('id')->on('addresses')->onUpdate('cascade')->onDelete('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('restaurant_meta');
        Schema::dropIfExists('menus');
        Schema::dropIfExists('addresses');
    }
}
