<?php

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| Here you may define all of your model factories. Model factories give
| you a convenient way to create models for testing and seeding your
| database. Just tell the factory how a default model should look.
|
*/

/** @var \Illuminate\Database\Eloquent\Factory $factory */
$factory->define(App\User::class, function (Faker\Generator $faker) {
    static $password;

    return [
        'name' => $faker->name,
        'email' => $faker->unique()->safeEmail,
        'password' => $password ?: $password = bcrypt('secret'),
        'remember_token' => str_random(10),
    ];
});

$factory->define(App\Admin::class, function (Faker\Generator $faker) {
    static $password;
    $roles = ['administrator', 'superadmin', 'editor', 'author', 'contributor', 'subscriber'];

    return [
        'name' => $faker->name,
        'email' => $faker->unique()->safeEmail,
        'username' => str_random(8),
        'auth_key' => str_random(12),
        'password' => $password ?: $password = bcrypt('password'),
        'role' => $roles[array_rand($roles)],
        'remember_token' => str_random(10),
    ];
});


$factory->define(App\Models\Address::class, function (Faker\Generator $faker) {
    $states = ["AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"];

    $cities = ["New York[6]","Los Angeles","Chicago","Houston[7]","Phoenix","Philadelphia[8]","San Antonio","San Diego","Dallas","San Jose","Austin","Jacksonville[9]","San Francisco[10]","Columbus","Indianapolis[11]","Fort Worth","Charlotte","Seattle","Denver[12]","El Paso","Washington[13]","Boston","Detroit","Nashville[14]","Memphis","Portland","Oklahoma City","Las Vegas","Louisville[15]","Baltimore[16]","Milwaukee","Albuquerque","Tucson","Fresno","Sacramento","Mesa","Kansas City","Atlanta","Long Beach","Colorado Springs","Raleigh","Miami","Virginia Beach[16]","Omaha","Oakland","Minneapolis","Tulsa","Arlington","New Orleans[17]","Wichita","Cleveland","Tampa","Bakersfield","Aurora","Honolulu[2]","Anaheim","Santa Ana","Corpus Christi","Riverside","Lexington[18]","St. Louis[16]","Stockton","Pittsburgh","Saint Paul","Cincinnati","Anchorage[19]"];

    $zips = ["33132","14202","10013","30303","10001","10011","10003","33023","10005","20151","22201","20001","10025","10044","20011","21215","55442","11201","10002","30324","10022","11215","10010","32202","14221","10024","20002","10021","43201","11211","33010","15212","44102","33442","43215","02124","55124","10004","11221","10023","10452","20005","33332","02215","11101","30024","23220","32210","11203","30022","22102","22033","30331","33134","11413","21043","11233","30004","43231","11234","33411","10012","23452","22030","11230","11212","11220","10032","21224","33142","22314","10014","11001","10033","10314","53214","21234","33311","10451","33025","10454","11213","15210","20003","44124","34243","11530","33125","11235","55112"];

    $counties = ["Afghanistan","Albania","Algeria","Andorra","Angola","Antigua & Deps","Argentina","Armenia","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bhutan","Bolivia","Bosnia Herzegovina","Botswana","Brazil","Brunei","Bulgaria","Burkina","Burundi","Cambodia","Cameroon","Canada","Cape Verde","Central African Rep","Chad","Chile","China","Colombia","Comoros","Congo","Congo {Democratic Rep}","Costa Rica","Croatia","Cuba","Cyprus","Czech Republic","Denmark","Djibouti","Dominica","Dominican Republic","East Timor","Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia","Fiji","Finland","France","Gabon","Gambia","Georgia","Germany","Ghana","Greece","Grenada","Guatemala","Guinea","Guinea-Bissau","Guyana","Haiti","Honduras","Hungary","Iceland","India","Indonesia","Iran","Iraq","Ireland {Republic}","Israel","Italy","Ivory Coast","Jamaica","Japan","Jordan","Kazakhstan","Kenya","Kiribati","Korea North","Korea South","Kosovo","Kuwait","Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg","Macedonia","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Mauritania","Mauritius","Mexico","Micronesia","Moldova","Monaco","Mongolia","Montenegro","Morocco","Mozambique","Myanmar, {Burma}","Namibia","Nauru","Nepal","Netherlands","New Zealand","Nicaragua","Niger","Nigeria","Norway","Oman","Pakistan","Palau","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Poland","Portugal","Qatar","Romania","Russian Federation","Rwanda","St Kitts & Nevis","St Lucia","Saint Vincent & the Grenadines","Samoa","San Marino","Sao Tome & Principe","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","South Sudan","Spain","Sri Lanka","Sudan","Suriname","Swaziland","Sweden","Switzerland","Syria","Taiwan","Tajikistan","Tanzania","Thailand","Togo","Tonga","Trinidad & Tobago","Tunisia","Turkey","Turkmenistan","Tuvalu","Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","Uruguay","Uzbekistan","Vanuatu","Vatican City","Venezuela","Vietnam","Yemen","Zambia","Zimbabwe"];

    return [
        'street'     => $faker->name,
        'city'       => $cities[array_rand($cities)],
        'state'      => $states[array_rand($states)],
        'zipcode'    => $zips[array_rand($zips)],
        'country'    => $counties[array_rand($counties)],
        'restaurant' => $faker->name,
        'tag_name' => $faker->name
    ];
});

