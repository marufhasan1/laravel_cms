<?php

use Illuminate\Database\Seeder;
use App\Role;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $roles = [
            'administrator' => ["write", "read", "edit", "delete", "publish", "download", "share", "approve"],
            'superadmin' => ["write", "read", "edit", "delete", "publish", "download", "share", "approve"],
            'editor' => ["write", "read", "edit", "delete", "publish", "download", "share"],
            'author' => ["write", "read", "edit", "delete", "publish", "download", "share"],
            'contributor' => ["write", "read", "edit", "delete", "publish", "download"],
            'subscriber' => ["write", "read", "edit", "delete", "publish", "download", "share"]
        ];

        foreach($roles as $key => $value) {
            Role::create([
                'name' => strtoupper($key),
                'slug' => str_replace(" ", "-", strtolower($key)),
                'permissions' => json_encode($value)
            ]);
        }


    }
}
