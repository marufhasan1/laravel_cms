<?php
return [

    "default" => [
    	"name" 					=> "Your Company Name",
    	"sub_title" 			=> "Company Address or Another Subtitle",
    	"about_company" 		=> "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt aperiam culpa, laudantium ab quaerat, eveniet itaque adipisci optio cumque unde eum sunt dolor at voluptatem corporis aliquam, laborum tenetur suscipit.",
    	"about_company_image" 	=> "https://image.shutterstock.com/z/stock-photo-close-up-image-of-business-partners-handshake-over-office-desk-during-meeting-1145256341.jpg",
    	"map" 	=> "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1811.547454935462!2d90.41015114017489!3d24.757934803088897!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x37564f91b7db155d%3A0x14b2d4bfe7dd000f!2sUS+IT+Solution+LLC!5e0!3m2!1sen!2sbd!4v1549965263995",
    ],
];

