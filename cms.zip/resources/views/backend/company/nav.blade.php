<ul class="pull-left" role="{{ $role }}">
    <li data-label="company-add"><a href="{{ url('admin/company') }}">Add Company</a></li>
    <li data-label="company-all"><a href="{{ url('admin/company/all') }}">All Company</a></li>
</ul>