@extends('backend.master.app', ['page' => 'company-add'])

{{-- body content start --}}
@section('content')
    <div class="{{ $width or 'container' }}" ng-controller="ProductCtrl">
        <div class="row">
            <div class="col-md-12">

                <!-- alert message start -->
                {!! session('success') !!}
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                <!-- alert message end -->
                <form method="POST" action="" class="form-horizontal ng-pristine ng-valid">
                    {{csrf_field()}}
                    <div class="form-group required">
                        <label for="fullname" class="col-sm-2 control-label">Company Name</label>

                        <div class="col-sm-10">
                            <input type="text" name="company_name" value="" class="form-control" required="">
                        </div>
                    </div>
					
					<div class="form-group required">
                        <label class="col-sm-2 control-label">Type </label>

                        <div class="col-sm-10">
                            <select class="form-control" name="type" required="">
                                <option value="" selected="">Select One</option>
                                <option value="smoke_shope">Smoke Shope</option>
                                <option value="filling_station">Filling Station</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group required">
                        <label for="contact_number" class="col-sm-2 control-label">Contact Number</label>

                        <div class="col-sm-10">
                            <input type="text" name="contact_number" value="" class="form-control" required="">
                        </div>
                    </div>

                    <div class="form-group required">
                        <label for="username" class="col-sm-2 control-label">Username</label>

                        <div class="col-sm-10">
                            <input type="text" name="site_url" value="" class="form-control" required="">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="street" class="col-sm-2 control-label">Street Number</label>

                        <div class="col-sm-10">
                            <input type="text" name="street_number" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="route" class="col-sm-2 control-label">Route</label>

                        <div class="col-sm-10">
                            <input type="text" name="route" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="city" class="col-sm-2 control-label">City</label>

                        <div class="col-sm-10">
                            <input type="text" name="city" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="state" class="col-sm-2 control-label">State</label>

                        <div class="col-sm-10">
                            <input type="text" name="state" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="zipcode" class="col-sm-2 control-label">Zipcode</label>

                        <div class="col-sm-10">
                            <input type="text" name="zipcode" class="form-control">
                        </div>
                    </div>
					
                    <div class="form-group">
                        <label for="country" class="col-sm-2 control-label">Country</label>

                        <div class="col-sm-10">
                            <input type="text" name="country" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-12">
                            <div class="pull-right">
                                <button type="submit" class="btn btn-default">Save</button>
                                <button type="reset" class="btn btn-danger">Reset</button>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
    {{-- body content end --}}
@endsection