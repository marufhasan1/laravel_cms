@extends('backend.master.app', ['page' => 'company-theme'])

{{-- body content start --}}
@section('content')
<style type="text/css" media="screen">
    .btn{
        margin-left: 0px;
    }
    .gallery{
        margin-top: 25px;
    }
	.theme-thumbnail{
		position: relative;
		width: 100%;
		height: 280px;
		overflow: hidden;
		margin-bottom: 5px;
		border: 5px solid #fff;
		border-radius: 3px;
	}
	.theme-thumbnail .img-thumbnail{
		width: 100%;
		height: auto;
		border: 0;
		padding: 0;
		border-radius: 0;
	}
	.theme-active:after{
		position: absolute;
		content:"Activeted";
		left: -48px;
		top: 24px;
		width: 180px;
		height: 36px;
		padding: 6px 10px;
		transform: rotate(-45deg);
		background: #5cb85c;
		text-align: center;
		font-weight: bolder;
		color: #ffffff;
		z-index: 3;
	}
</style>
<div class="{{ $width or 'container' }}">
    <div class="row">
        <div class="col-md-12">

            <!-- alert message start -->
            {!! session('success') !!}
            <!-- alert message end -->

            <div class="col-md-12 gallery" >
                <div class="row">
                    @foreach ($allTheme as $theme)
                    {{-- <pre>{{print_r($theme,1)}}</pre> --}}
                    <div class="col-md-3 gallery-image" style="">
                        <span>{{$theme->title}}</span>
                        <div class="theme-thumbnail {{(isset($current->value) && $theme->id==$current->value) ? "theme-active" : ""}}"><img src="{{asset($theme->thumb)}}" alt="" class="img-thumbnail"></div>
                        <a href="{{url("admin/company/set_theme/".$theme->id)}}" class="btn btn-success btn-block">Active This Theme</a>
                    </div>
                    @endforeach
                </div>
            </div>

        </div>
    </div>
</div>
{{-- body content end --}}
@endsection