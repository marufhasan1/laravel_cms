@extends('backend.master.app', ['page' => 'company-about_company'])

{{-- body content start --}}
@section('content')
<script src="{{ asset('public/admin/ckeditor/ckeditor.js') }}"></script>
<style type="text/css" media="screen">
    .btn{
        margin-left: 0px;
    }
</style>
    <div class="{{ $width or 'container' }}" ng-controller="ProductCtrl">
        <div class="row">
            <div class="col-md-12">

                <!-- alert message start -->
                {!! session('success') !!}
                <!-- alert message end -->
                
                <form method="POST" action="" enctype="multipart/form-data" class="form-horizontal ng-pristine ng-valid">
                    {{csrf_field()}}
                    <input type="hidden" name="old_image" value="{{$about_image->upload_path or ""}}">
                    <div class="form-group">
                        <div class="col-sm-12">
                            <textarea id="editor" name="about_company" class="form-control">{{$info->meta_value or ""}}</textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="image" class="col-sm-2 control-label">About Image</label>

                        <div class="col-sm-10">
                            <input type="file" id="image" name="about_image" value="" class="form-control">
                        </div>
                    </div>
                
                    <div class="form-group">
                        <div class="col-sm-10">
                            <div class="pull-left">
                                <button type="submit" class="btn btn-success">Update</button>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-5">
                            @if (isset($about_image->upload_path))
                                <img src="{{ asset("storage/app/".$about_image->upload_path) }}" alt="" class="img-responsive img-thumbnail">
                            @endif
                        </div>
                    </div>

                </form>

            </div>
        </div>
    </div>
<script>
    CKEDITOR.replace("editor");
</script>
    {{-- body content end --}}
@endsection