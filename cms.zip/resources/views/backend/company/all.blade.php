@extends('backend.master.app', ['page' => 'company-all'])
{{-- body content start --}}
@section('content')
<div class="{{ $width or 'container'}}" >

    <!-- alert message start -->
    @if (session('alert'))
        {!! session('alert') !!}
    @endif
    <!-- alert message end -->


    <div class="row">
        <div class="col-md-12">

            <!-- alert message start -->
            {!! session('success') !!}
            <!-- alert message end -->
            <table class="table">
            	<thead>
            		<tr>
            			<th>SL</th>
            			<th>Name</th>
            			<th>URL</th>
                        <th>Contact Number</th>
            			<th>Status</th>
            			<th>Action</th>
            		</tr>
            	</thead>

            	<tbody>
                    @foreach ($info as $key => $row)
                    <tr>
                        <td>{{$key+1}}</td>
                        <td>{{$row->company_name}}</td>
                        <td>
                            <a target="_blank" href="http://{{$row->site_url.".".config("app.domain")}}">{{$row->site_url.".".config("app.domain")}}</a>
                        </td>
                        <td><a href="tel:{{$row->contact_number}}">{{$row->contact_number}}</a></td>
                        <td>{{$row->status}}</td>
                        <td>
                            <a href="{{url("admin/company/edit/".$row->id)}}" class="btn btn-primary">Update</a>
                            <a onclick="return confirm('Are you sure to delete this Company?')" href="{{url("admin/company/delete_company/".$row->id)}}" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
{{-- body content end --}}
