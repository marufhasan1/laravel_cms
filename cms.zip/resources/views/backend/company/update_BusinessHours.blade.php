@extends('backend.master.app', ['page' => 'company-business_hours'])

{{-- body content start --}}
@section('content')
<div class="{{ $width or 'container' }}" ng-controller="ProductCtrl">
    <div class="row">
        <div class="col-md-12">

            <!-- alert message start -->
            {!! session('success') !!}
            <!-- alert message end -->

            <form method="POST" action="#" class="ng-pristine ng-valid">
                {{csrf_field()}}
                <div class="row">
                    <div class="col-md-12">
                        <h3>Add activity</h3>
                        <hr>
                    </div>

                    <div>
                        <div class="form-group col-md-2">
                            <label for="sunday">
                                <input type="checkbox" name="status[]" value="Sunday" id="sunday" checked="">
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <span>Sunday</span>
                                <input type="hidden" name="day[]" value="Sunday" autocomplete="off">
                            </label>
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="open[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="close[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>
                    </div>

                    <div>
                        <div class="form-group col-md-2">
                            <label for="monday">
                                <input type="checkbox" name="status[]" value="Monday" id="monday" checked="">
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <span>Monday</span>
                                <input type="hidden" name="day[]" value="Monday" autocomplete="off">
                            </label>
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="open[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="close[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>
                    </div>

                    <div>
                        <div class="form-group col-md-2">
                            <label for="tuesday">
                                <input type="checkbox" name="status[]" value="Tuesday" id="tuesday" checked="">
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <span>Tuesday</span>
                                <input type="hidden" name="day[]" value="Tuesday" autocomplete="off">
                            </label>
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="open[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="close[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>
                    </div>

                    <div>
                        <div class="form-group col-md-2">
                            <label for="wednesday">
                                <input type="checkbox" name="status[]" value="Wednesday" id="wednesday" checked="">
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <span>Wednesday</span>
                                <input type="hidden" name="day[]" value="Wednesday" autocomplete="off">
                            </label>
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="open[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="close[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>
                    </div>

                    <div>
                        <div class="form-group col-md-2">
                            <label for="thursday">
                                <input type="checkbox" name="status[]" value="Thursday" id="thursday" checked="">
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <span>Thursday</span>
                                <input type="hidden" name="day[]" value="Thursday" autocomplete="off">
                            </label>
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="open[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="close[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>
                    </div>

                    <div>
                        <div class="form-group col-md-2">
                            <label for="friday">
                                <input type="checkbox" name="status[]" value="Friday" id="friday" checked="">
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <span>Friday</span>
                                <input type="hidden" name="day[]" value="Friday" autocomplete="off">
                            </label>
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="open[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="close[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>
                    </div>

                    <div>
                        <div class="form-group col-md-2">
                            <label for="saturday">
                                <input type="checkbox" name="status[]" value="Saturday" id="saturday" checked="">
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <span>Saturday</span>
                                <input type="hidden" name="day[]" value="Saturday" autocomplete="off">
                            </label>
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="open[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>

                        <div class="form-group col-md-5">
                            <input type="text" name="close[]" value="" class="timePicker form-control" placeholder="HH:MM:SS">
                        </div>
                    </div>

                    <div class="form-group col-md-12 text-right">
                        <input type="submit" name="save" value="Save" class="btn btn-info">
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>

@push('scripts')
   <script>
		$( ".timePicker" ).focus(function() {
			$( this ).timepicker();
		});
	</script>
@endpush

{{-- body content end --}}
@endsection