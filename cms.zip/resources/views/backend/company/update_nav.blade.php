<ul class="pull-left" role="{{ $role }}">
    <li data-label="company-header"><a href="{{ url('admin/company/update') }}">Header Section</a></li>
    <li data-label="company-about_company"><a href="{{ url('admin/company/update/about_company') }}">About Company</a></li>
    <li data-label="company-gallery_image"><a href="{{ url('admin/company/update/gallery_image') }}">Gallery Image</a></li>
    <li data-label="company-business_hours"><a href="{{ url('admin/company/update/business_hours') }}">Business Hours</a></li>
    <li data-label="company-others"><a href="{{ url('admin/company/update/others') }}">Others</a></li>
    <li data-label="company-theme"><a href="{{ url('admin/company/update/theme') }}">Choice Theme</a></li>
</ul>