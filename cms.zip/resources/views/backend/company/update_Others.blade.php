@extends('backend.master.app', ['page' => 'company-others'])

{{-- body content start --}}
@section('content')
<style type="text/css" media="screen">
    .btn{
        margin-left: 0px;
    }
</style>
    <div class="{{ $width or 'container' }}" ng-controller="ProductCtrl">
        <div class="row">
            <div class="col-md-12">

                <!-- alert message start -->
                {!! session('success') !!}
                <!-- alert message end -->
                
                <form method="POST" action="" class="form-horizontal ng-pristine ng-valid">
                {{csrf_field()}}
                <div class="form-group">
                    <label for="latitude" class="col-sm-2 control-label">Map Embade Code </label>

                    <div class="col-sm-10">
                        <input type="text" name="map" value="" placeholder="e.g. <iframe></iframe>" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <label for="cellphone" class="col-sm-2 control-label">Contact No</label>

                    <div class="col-sm-10">
                        <input type="text" name="contact_number" value="{{$info->contact_number}}" class="form-control">
                    </div>
                </div>

                <fieldset>
                    <legend>Address</legend>
                    <div class="form-group">
                        <label for="street" class="col-sm-2 control-label">Street Number</label>

                        <div class="col-sm-10">
                            <input type="text" name="street_number" value="{{$info->street_number}}" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="route" class="col-sm-2 control-label">Route</label>

                        <div class="col-sm-10">
                            <input type="text" name="route" value="{{$info->route}}" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="city" class="col-sm-2 control-label">City</label>

                        <div class="col-sm-10">
                            <input type="text" name="city" value="{{$info->city}}" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="state" class="col-sm-2 control-label">State</label>

                        <div class="col-sm-10">
                            <input type="text" name="state" value="{{$info->state}}" class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="zipcode" class="col-sm-2 control-label">Zipcode</label>

                        <div class="col-sm-10">
                            <input type="text" name="zipcode" value="{{$info->zipcode}}" class="form-control">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="country" class="col-sm-2 control-label">Country</label>

                        <div class="col-sm-10">
                            <input type="text" name="country" value="{{$info->country}}" class="form-control">
                        </div>
                    </div>
                </fieldset>


                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <div class="pull-left">
                            <button type="submit" class="btn btn-success">Update</button>
                        </div>
                    </div>
                </div>
            </form>

            </div>
        </div>
    </div>
    {{-- body content end --}}
@endsection