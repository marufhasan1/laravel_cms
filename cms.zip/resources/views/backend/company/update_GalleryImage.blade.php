@extends('backend.master.app', ['page' => 'company-gallery_image'])

{{-- body content start --}}
@section('content')
<style type="text/css" media="screen">
    .gallery{
        margin-top: 70px;
    }
    .gallery .gallery-image{
        margin-bottom: 25px;
        min-width: 295px;
        min-height: 162px;
    }
    .gallery .gallery-image .img-thumbnail{
        border-radius: 0px;
    }
    .btn{
        margin-left: 0px
    }
</style>
<div class="{{ $width or 'container' }}" ng-controller="ProductCtrl">
    <div class="row">
        <div class="col-md-12">

            <!-- alert message start -->
            {!! session('success') !!}
            <!-- alert message end -->

            <form method="POST" action="" enctype="multipart/form-data" class="form-horizontal ng-pristine ng-valid">
                {{csrf_field()}}
                <div class="form-group">
                    <label for="username" class="col-sm-2 control-label">Gallery Image</label>

                    <div class="col-sm-10">
                        <input type="file" name="image" value="" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <div class="pull-left">
                            <button type="submit" class="btn btn-success">Update</button>
                        </div>
                    </div>
                </div>
            </form>

        </div>
        <div class="col-sm-offset-2 col-md-10 gallery" >
            <div class="row">
                @foreach ($images as $key => $image)
                <div class="col-md-4 gallery-image" style="">
                    <img src="{{ asset("storage/app/".$image->upload_path) }}" alt="" class="img-responsive img-thumbnail">
                    <a onclick="return confirm('Are you sure to delete this image?')" href="{{url("admin/company/delete_gallery/".$image->id)}}" class="btn btn-danger btn-block">Delete</a>
                </div>                
                @endforeach
            </div>
        </div>
    </div>
</div>
{{-- body content end --}}
@endsection