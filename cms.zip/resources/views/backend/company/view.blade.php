@extends('backend.master.app', ['page' => 'product-list'])

{{-- body content start --}}
@section('content')
    <div class="{{ $width or 'container' }}" ng-controller="ProductViewCtrl">
        <div class="row">
            <div class="col-md-12">
                <form method="POST" action="" enctype="multipart/form-data">
                    {{ csrf_field() }}
                    
                    <div class="row">
                        <!-- alert message start -->
                        {!! session('success') !!}
                        <!-- alert message end -->
                        
                            @php
                                $metainfo = [];
                                foreach ($info->GetProductMeta as $key => $value) {
                                    $metainfo[$value->meta_key][] = $value->meta_value;
                                }
                                //print_r($metainfo);
                                $description = (isset($metainfo["description"]) && $metainfo["description"]!=null) ? json_encode($metainfo["description"]) : null;
                                $price = (isset($metainfo["price"]) && $metainfo["price"]!=null) ? $metainfo["price"][0] : null;
                                $image = (isset($metainfo["image"]) && $metainfo["image"]!=null) ? $metainfo["image"][0] : "";
                            @endphp
                            
                            <input type="hidden" name="old_image" value="{{$image}}">
                            
                            <div class="form-group col-md-12 required">
                                <img class="img-thumbnail pull-right" style="width: 150px;" src="{{url($image)}}" alt="">
                            </div>
                            
                            <div class="form-group col-md-6 required">
                                <label for="contact-details" class="control-label">Product Name</label>
                                <input type="text" name="product_name" value="{{ $info->product_name }}" class="form-control" id="product_name" placeholder="Product Name" autofocus required>
                            </div>
                            
                            <div ng-init="category='{{$info->category}}'" ng-model="category" class="form-group col-md-6 required">
                                <label for="contact-details" class="control-label">Category</label>
                                {!! Form::select('category', array_combine($product_info["category"],$product_info["category"]), $info->category, ['class' => 'form-control','id' => 'category','required' => 'required','placeholder'=>'--Select--']) !!}
                            </div>

                            <div ng-if="category=='Accessories'" class="form-group col-md-6 required">
                                <label for="tax" class="control-label">Accessories Type</label>
                                {!! Form::select('type', array_combine($accessories_type,$accessories_type), $info->type, ['class' => 'form-control','id' => 'acc_type','required' => 'required','placeholder'=>'--Select--']) !!}
                            </div>
                            
                            <div class="form-group col-md-6">
                                <label for="tax" class="control-label">Brand</label>
                                {!! Form::select('brand', array_combine($product_info["brand"],$product_info["brand"]), $info->brand, ['class' => 'form-control','id' => 'brand','placeholder'=>'--Select--']) !!}
                            </div>
                            
                            <!-- <div class="form-group col-md-4">
                                <label for="name" class="control-label">Model</label>
                                <input type="text" name="model" value="{{ $info->model }}" class="form-control" id="model" placeholder="Model">
                            </div> -->
                            
                            <div class="form-group col-md-6">
                                <label for="imgs" class="control-label">Photo</label>
                                <input type="file" name="image" class="form-control" id="imgs" accept="image/*">
                            </div>
                            
                            <div class="form-group col-md-6" ng-init="description = {{$description}}">
                                    <label for="name" class="control-label">Description</label>
                                    <input ng-repeat="d in desckey" type="text" name="description[]" ng-model="d.value" class="form-control" id="model" placeholder="Description">
                                    <button type="button" class="btn btn-primary" ng-click="addDescription()" style="display: block; margin: 5px 0;">Add product feature</button>
                                </div>
                                
                                <div class="form-group col-md-6" ng-init="price = {{$price}}">
                                        <label class="control-label">  </label>
                                        <label><input type="radio" ng-model="price_type" value="single" name="price_type"> Price only </label>
                                        <label><input type="radio" ng-model="price_type" value="multiple" name="price_type"> Price with stoarge/ other's option </label>
                                        
                                        <div ng-if="price_type=='single'">
                                            <input type="text" name="price" class="form-control" ng-value="single_price" id="price" placeholder="Price">
                                        </div>
                                        <div ng-if="price_type=='multiple'">
                                            <table style="width: 100%; border-collapse: collapse;">
                                                <tr ng-repeat="p in prices">
                                                    <td><input type="text" name="price[]" ng-value="p.price" class="form-control" id="price" placeholder="Price"></td>
                                                    <td><input type="text" name="storage[]" ng-value="p.storage" class="form-control" id="price" placeholder="Example: 16GB"></td>
                                                    <td><a href="#" ng-click="removePrice($index)" class="btn btn-danger"> X </a></td>
                                                </tr>
                                                <tr>
                                                    <td colspan="3"><button type="button" class="btn btn-primary" ng-click="addPrice()">Add More Price</button></td>
                                                </tr>
                                            </table>
                                            
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    <div class="form-group col-md-12 text-right">
                                        <input type="submit" value="Update" class="btn btn-info">
                                    </div>
                                </div>
                </form>
                    
            </div>
        </div>
    </div>
    {{-- body content end --}}
@endsection
@push('scripts')
    <script type="text/javascript" src="{{ asset('public/admin/js/controllers/productViewController.js') }}"></script>
@endpush