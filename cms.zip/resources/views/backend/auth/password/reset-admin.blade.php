@extends('backend.master.authentication')

{{-- extent credential --}}
@section('credential')
<form method="POST" action="{{ route('admin.password.request') }}">
    <strong>Change Password</strong>
    {{ csrf_field() }}

    <input type="hidden" name="token" value="{{ $token }}">

    <div class="{{ $errors->has('email') ? ' has-error' : '' }}">
        <label for="">
            <input type="email" name="email" placeholder="E-Mail Address" value="{{ $email or old('email') }}" required autofocus>
        </label>

        @if ($errors->has('email'))
            <span class="help-block">
                <strong>{{ $errors->first('email') }}</strong>
            </span>
        @endif
    </div>

    <div class="{{ $errors->has('password') ? ' has-error' : '' }}">
        <label for="">
            <input type="password" name="password" placeholder="New password" required>
        </label>

        @if ($errors->has('password'))
            <span class="help-block">
                <strong>{{ $errors->first('password') }}</strong>
            </span>
        @endif
    </div>

    <div class="{{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
        <label for="">
            <input type="password" name="password_confirmation" placeholder="Confirm password" required>
        </label>

        @if ($errors->has('password_confirmation'))
            <span class="help-block">
                <strong>{{ $errors->first('password_confirmation') }}</strong>
            </span>
        @endif
    </div>

    <div class="">
        <button type="submit">Reset Password</button>
    </div>
</form>
@endsection

{{-- extent link --}}
@section('link')
    <a href="{{ url('/') }}">Home</a>
    <a class="link" href="{{ route('admin.login') }}">Sign In</a>
@endsection

{{-- extent alert message --}}
@section('alert')
    @if (session('status'))
        <p>{{ session('status') }}</p>
    @endif
@endsection
