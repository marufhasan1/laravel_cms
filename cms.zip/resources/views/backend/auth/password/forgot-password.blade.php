@extends('backend.master.authentication')

{{-- extent credential --}}
@section('credential')
<form method="POST" action="{{ route('admin.password.email') }}">
    <strong>Forgot Password?</strong>
    {{ csrf_field() }}

    <div class="{{ $errors->has('email') ? ' has-error' : '' }}">
        <input type="email" name="email" placeholder="E-Mail Address" value="{{ old('email') }}" required>

        @if ($errors->has('email'))
            <span class="help-block">
                <strong>{{ $errors->first('email') }}</strong>
            </span>
        @endif
    </div>

    <div>
        <button type="submit">Send password reset link</button>
    </div>
</form>
@endsection

{{-- extent link --}}
@section('link')
    <a href="{{ url('/') }}">Home</a>
    <a class="link" href="{{ route('admin.login') }}">Sign In</a>
@endsection

{{-- extent alert message --}}
@section('alert')
    @if (session('status'))
        <p>{{ session('status') }}</p>
    @endif
@endsection
