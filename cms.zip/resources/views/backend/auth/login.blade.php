@extends('backend.master.authentication')

@section('credential')
<form method="POST" action="{{ route('admin.login.submit') }}">
    <strong>Sign In</strong>

    {{ csrf_field() }}

    <div class="{{ $errors->has('email') ? ' has-error' : '' }}">
        <label for="">
            <input type="email" name="email" placeholder="E-Mail Address" value="{{ old('email') }}" required autofocus>
        </label>

        @if ($errors->has('email'))
            <span class="help-block">
                <strong>{{ $errors->first('email') }}</strong>
            </span>
        @endif
    </div>

    <div class="{{ $errors->has('password') ? ' has-error' : '' }}">
        <label for="">
            <input type="password" name="password" placeholder="Password" required>
        </label>

        @if ($errors->has('password'))
            <span class="help-block">
                <strong>{{ $errors->first('password') }}</strong>
            </span>
        @endif
    </div>

    <div class="remember">
        <label>
            <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}>
            Remember me
        </label>
    </div>

    <div class="">
        <button type="submit">Sign In</button>
    </div>
</form>
@endsection
