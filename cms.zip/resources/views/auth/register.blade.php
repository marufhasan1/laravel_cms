@extends('frontend.layouts.master', ['page' => 'index', 'search' => false])

@section('content')
    <section class="account">
        <div class="container">
            <div class="row">
                <div class="account-form">
                    <h4 class="section-title">Register Now</h4>
                    {{--<p class="msg-alert"> <em>Show Message For Any error</em> </p>--}}

                    <form class="pt-3" method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}

                        <div class="{{ $errors->has('name') ? ' has-error' : '' }}">
                            <div class="form-wrapper">
                                <input type="text" class="form-input form-input-l" name="first_name" value="{{ old('first_name') }}" placeholder="First Name" required autofocus>

                                <input type="text" class="form-input form-input-r" name="last_name" value="{{ old('last_name') }}" placeholder="Last Name" required autofocus>
                            </div>

                            @if ($errors->has('first_name'))
                                <p class="msg-alert"><em>{{ $errors->first('first_name') }}</em></p>
                            @endif

                            @if ($errors->has('last_name'))
                                <p class="msg-alert"><em>{{ $errors->first('last_name') }}</em></p>
                            @endif
                        </div>

                        <div class="{{ $errors->has('email') ? ' has-error' : '' }}">
                            <input type="email" class="form-input" name="email" value="{{ old('email') }}" placeholder="Email Address" required>

                            @if ($errors->has('email'))
                                <p class="msg-alert"><em>{{ $errors->first('email') }}</em></p>
                            @endif
                        </div>

                        <div class="{{ $errors->has('phone_number') ? ' has-error' : '' }}">
                            <input type="text" class="form-input" name="phone_number" value="{{ old('phone_number') }}" placeholder="Phone No" required>

                            @if ($errors->has('phone_number'))
                                <p class="msg-alert"><em>{{ $errors->first('phone_number') }}</em></p>
                            @endif
                        </div>

                        <div class="{{ $errors->has('password') ? ' has-error' : '' }}">
                            <input type="password" class="form-input" id="password" name="password" placeholder="Type Password" required>

                            @if ($errors->has('password'))
                                <p class="msg-alert">
                                    <em>{{ $errors->first('password') }}</em>
                                </p>
                            @endif
                        </div>

                        <input type="password" class="form-input" name="password_confirmation" placeholder="Re-Type Password" required>

                        <div>
                            <button type="submit" class="btn btnSubmit">Register Now</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
@endsection