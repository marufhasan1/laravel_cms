@extends('theme.layout.master', ['page' => 'index', 'search' => false])

@section('container')
    <section class="account">
        <div class="container">
            <div class="row">
                <div class="account-form">
                    <h4 class="section-title">Forgot Password?</h4>
                    {{--<p class="msg-alert"> <em>This Email Doesn't Matched</em> </p>--}}

                    @if (session('status'))
                        <p class="msg-alert-success"><em>{{ session('status') }}</em></p>
                    @endif

                    <form class="pt-3" method="POST" action="{{ route('password.email') }}">
                        {{ csrf_field() }}

                        <div class="{{ $errors->has('email') ? ' has-error' : '' }}">
                            <input type="email" class="form-input" name="email" value="{{ $email or old('email') }}" placeholder="Email Address" required autofocus>

                            @if ($errors->has('email'))
                                <p class="msg-alert"><em>{{ $errors->first('email') }}</em></p>
                            @endif
                        </div>

                        <button type="submit" class="btn btnSubmit">Send Password Reset Link</button>
                    </form>

                    <p class="text-link"> Back to <a href="{{ route('login') }}">Sign in</a> </p>
                </div>
            </div>
        </div>
    </section>
@endsection
