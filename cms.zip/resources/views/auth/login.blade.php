@extends('frontend.layouts.master', ['page' => 'index', 'search' => false])

@section('content')
    <section class="account">
        <div class="container">
            <div class="row">
                <div class="account-form">
                    <h4 class="section-title">Sign In</h4>

                    @if ($errors->has('email'))
                        <p class="msg-alert"><em>Wrong Username or, Password</em></p>
                    @endif

                    <form class="pt-3" method="POST" action="{{ route('login') }}">
                        {{ csrf_field() }}

                        <div class="{{ $errors->has('email') ? ' has-error' : '' }}">
                            <input type="email" class="form-input" name="email" value="{{ old('email') }}" placeholder="Email Address" required autofocus>
                        </div>

                        <div class="{{ $errors->has('password') ? ' has-error' : '' }}">
                            <input type="password" class="form-input" name="password" placeholder="Your Password" required>
                        </div>

                        <div>
                            <label>
                                <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}>
                                Remember Me
                            </label>
                        </div>

                        <div>
                            <button type="submit" class="btn btnSubmit">Sign In Now</button>
                        </div>
                    </form>

                    <p class="text-link">
                        <a class="btn btn-link" href="{{ route('password.request') }}">Forgot Your Password?</a>
                    </p>
                </div>
            </div>
        </div>
    </section>
@endsection